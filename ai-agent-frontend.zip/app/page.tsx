import type { Metadata } from "next"
import DashboardView from "@/components/dashboard/dashboard-view"

export const metadata: Metadata = {
  title: "ASU Student Planner | Organize Your Semester",
  description:
    "Personal planner for ASU students to manage daily, weekly, and semester goals with Canvas and MyASU integration.",
}

export default function HomePage() {
  return (
    <main className="flex-1 overflow-auto">
      <DashboardView />
    </main>
  )
}

