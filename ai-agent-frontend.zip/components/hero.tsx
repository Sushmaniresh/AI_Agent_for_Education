export default function Hero() {
  return (
    <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-600 to-indigo-700">
      <div className="container px-4 md:px-6 mx-auto">
        <div className="flex flex-col items-center space-y-4 text-center">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none text-white">
              Your Intelligent AI Assistant
            </h1>
            <p className="mx-auto max-w-[700px] text-gray-200 md:text-xl">
              Ask questions, get recommendations, and solve problems with our advanced AI agent.
            </p>
          </div>
          <div className="space-x-4">
            <a
              href="#chat"
              className="inline-flex h-10 items-center justify-center rounded-md bg-white px-8 text-sm font-medium text-blue-600 shadow transition-colors hover:bg-gray-100 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-blue-500"
            >
              Start Chatting
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

