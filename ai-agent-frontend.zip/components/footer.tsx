import Link from "next/link"
import { GraduationCap } from "lucide-react"

export default function Footer() {
  return (
    <footer className="w-full border-t bg-asu-maroon text-white py-6">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <div className="flex items-center gap-2">
          <GraduationCap className="h-5 w-5 text-asu-gold" />
          <p className="text-center text-sm leading-loose md:text-left">
            © {new Date().getFullYear()} ASU Student Planner. All rights reserved.
          </p>
        </div>
        <div className="flex gap-4">
          <Link href="#" className="text-sm font-medium text-white hover:text-asu-gold">
            Terms
          </Link>
          <Link href="#" className="text-sm font-medium text-white hover:text-asu-gold">
            Privacy
          </Link>
          <Link href="#" className="text-sm font-medium text-white hover:text-asu-gold">
            Help
          </Link>
        </div>
      </div>
    </footer>
  )
}

