"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import TodayTasks from "@/components/dashboard/today-tasks"
import DailyPlanner from "@/components/dashboard/daily-planner"
import WeeklyTasks from "@/components/dashboard/weekly-tasks"
import MonthlyPlanner from "@/components/dashboard/monthly-planner"
import SemesterGoals from "@/components/dashboard/semester-goals"
import CalendarView from "@/components/calendar/calendar-view"
import CollabView from "@/components/collab/collab-view"
import AISystemView from "@/components/chatbot/ai-system-view"
import { Calendar, Users, ListTodo, Bot } from "lucide-react"
import ActivityTracker from "@/components/dashboard/activity-tracker"

export default function DashboardView() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <div className="container mx-auto py-6 px-4 md:px-6">
      <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="bg-gradient-to-r from-asu-maroon to-asu-maroon/80 text-white p-3 rounded-lg shadow-md w-full md:w-auto">
            <h1 className="text-3xl font-bold tracking-tight flex items-center">
              <span className="text-asu-gold mr-2">Sun Devil</span> Planner
            </h1>
            <p className="text-sm text-white/80">Organize your academic journey at Arizona State University</p>
          </div>
          <TabsList className="bg-white dark:bg-gray-800 p-1 shadow-md">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <ListTodo className="h-4 w-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="calendar" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Calendar className="h-4 w-4 mr-2" />
              Calendar
            </TabsTrigger>
            <TabsTrigger value="collab" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Users className="h-4 w-4 mr-2" />
              Find Professors
            </TabsTrigger>
            <TabsTrigger value="ai" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Bot className="h-4 w-4 mr-2" />
              AI System
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="dashboard" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <TodayTasks />
            <DailyPlanner />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <WeeklyTasks />
            <MonthlyPlanner />
          </div>
          <SemesterGoals />
          <ActivityTracker />
        </TabsContent>

        <TabsContent value="calendar">
          <CalendarView />
        </TabsContent>

        <TabsContent value="collab">
          <CollabView />
        </TabsContent>

        <TabsContent value="ai">
          <AISystemView />
        </TabsContent>
      </Tabs>
    </div>
  )
}

