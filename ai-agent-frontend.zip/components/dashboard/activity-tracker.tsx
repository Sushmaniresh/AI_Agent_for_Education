"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Activity,
  Brain,
  Code,
  BookOpen,
  Clock,
  Moon,
  Smile,
  Frown,
  Meh,
  BarChart,
  Calendar,
  Zap,
  Award,
  Users,
  Mountain,
  Presentation,
  Laptop,
  Coffee,
  Utensils,
  Dumbbell,
  Music,
  Film,
  Bookmark,
  Github,
  Linkedin,
  Figma,
  Codepen,
} from "lucide-react"

// Enhanced color palette
const colorPalette = {
  primary: {
    maroon: "rgba(140, 29, 64, 1)",
    gold: "rgba(255, 198, 39, 1)",
    maroonLight: "rgba(140, 29, 64, 0.1)",
    goldLight: "rgba(255, 198, 39, 0.1)",
  },
  coding: {
    green: "rgba(16, 185, 129, 1)",
    blue: "rgba(59, 130, 246, 1)",
    purple: "rgba(139, 92, 246, 1)",
    teal: "rgba(20, 184, 166, 1)",
    greenLight: "rgba(16, 185, 129, 0.2)",
    blueLight: "rgba(59, 130, 246, 0.2)",
    purpleLight: "rgba(139, 92, 246, 0.2)",
    tealLight: "rgba(20, 184, 166, 0.2)",
  },
  study: {
    indigo: "rgba(99, 102, 241, 1)",
    violet: "rgba(124, 58, 237, 1)",
    fuchsia: "rgba(217, 70, 239, 1)",
    indigoLight: "rgba(99, 102, 241, 0.2)",
    violetLight: "rgba(124, 58, 237, 0.2)",
    fuchsiaLight: "rgba(217, 70, 239, 0.2)",
  },
  wellness: {
    emerald: "rgba(16, 185, 129, 1)",
    amber: "rgba(245, 158, 11, 1)",
    rose: "rgba(244, 63, 94, 1)",
    emeraldLight: "rgba(16, 185, 129, 0.2)",
    amberLight: "rgba(245, 158, 11, 0.2)",
    roseLight: "rgba(244, 63, 94, 0.2)",
  },
  sleep: {
    sky: "rgba(14, 165, 233, 1)",
    cyan: "rgba(6, 182, 212, 1)",
    blue: "rgba(59, 130, 246, 1)",
    skyLight: "rgba(14, 165, 233, 0.2)",
    cyanLight: "rgba(6, 182, 212, 0.2)",
    blueLight: "rgba(59, 130, 246, 0.2)",
  },
  priority: {
    high: "rgba(239, 68, 68, 1)",
    medium: "rgba(245, 158, 11, 1)",
    low: "rgba(16, 185, 129, 1)",
    highLight: "rgba(239, 68, 68, 0.2)",
    mediumLight: "rgba(245, 158, 11, 0.2)",
    lowLight: "rgba(16, 185, 129, 0.2)",
  },
}

// Event types with icons and colors
const eventTypes = {
  class: { icon: BookOpen, color: colorPalette.study.indigo },
  assignment: { icon: Bookmark, color: colorPalette.priority.high },
  study: { icon: BookOpen, color: colorPalette.study.violet },
  meeting: { icon: Users, color: colorPalette.coding.blue },
  club: { icon: Users, color: colorPalette.coding.purple },
  hackathon: { icon: Laptop, color: colorPalette.coding.teal },
  hike: { icon: Mountain, color: colorPalette.wellness.emerald },
  seminar: { icon: Presentation, color: colorPalette.study.fuchsia },
  workout: { icon: Dumbbell, color: colorPalette.wellness.emerald },
  meal: { icon: Utensils, color: colorPalette.wellness.amber },
  coffee: { icon: Coffee, color: colorPalette.wellness.amber },
  entertainment: { icon: Film, color: colorPalette.wellness.rose },
  music: { icon: Music, color: colorPalette.wellness.rose },
}

// Generate more comprehensive dummy data for a month
const generateMonthlyData = () => {
  const today = new Date()
  const daysInMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate()
  const monthData = []

  for (let i = 0; i < daysInMonth; i++) {
    const date = new Date(today.getFullYear(), today.getMonth(), i + 1)

    // Skip future dates
    if (date > today) continue

    // Generate random data with some patterns
    const isWeekend = date.getDay() === 0 || date.getDay() === 6
    const leetcodeTime = isWeekend ? Math.random() * 3 + 1 : Math.random() * 2
    const studyTime = isWeekend ? Math.random() * 2 : Math.random() * 5 + 2
    const sleepHours = isWeekend ? Math.random() * 2 + 7 : Math.random() * 2 + 6

    // Create mood patterns (better on weekends, worse on Mondays)
    let mood
    if (isWeekend) {
      mood = Math.random() > 0.2 ? "happy" : "neutral"
    } else if (date.getDay() === 1) {
      // Monday
      mood = Math.random() > 0.6 ? "neutral" : "sad"
    } else {
      const moodRandom = Math.random()
      mood = moodRandom > 0.6 ? "happy" : moodRandom > 0.3 ? "neutral" : "sad"
    }

    // Generate events for the day
    const events = generateDailyEvents(date, isWeekend)

    // Generate coding platform data
    const githubCommits = Math.floor(Math.random() * 8)
    const githubPRs = Math.floor(Math.random() * 3)
    const leetcodeProblems = Math.floor(leetcodeTime * 2)
    const codepenProjects = Math.random() > 0.8 ? Math.floor(Math.random() * 2) + 1 : 0
    const figmaTime = Math.random() > 0.7 ? Number.parseFloat((Math.random() * 1.2).toFixed(1)) : 0

    monthData.push({
      date: date,
      leetcode: {
        timeSpent: Number.parseFloat(leetcodeTime.toFixed(1)),
        problems: leetcodeProblems,
        difficulty: {
          easy: Math.floor(Math.random() * 3),
          medium: Math.floor(Math.random() * 2),
          hard: Math.floor(Math.random() * 1),
        },
      },
      kaggle: {
        timeSpent: Number.parseFloat((Math.random() * 1.5).toFixed(1)),
        activity: Math.random() > 0.7,
      },
      linkedin: {
        timeSpent: Number.parseFloat((Math.random() * 0.8).toFixed(1)),
        activity: Math.random() > 0.6,
        connections: Math.floor(Math.random() * 3),
        posts: Math.random() > 0.8 ? 1 : 0,
      },
      github: {
        commits: githubCommits,
        pullRequests: githubPRs,
        issues: Math.floor(Math.random() * 2),
        timeSpent: Number.parseFloat((Math.random() * 2).toFixed(1)),
      },
      codepen: {
        projects: codepenProjects,
        timeSpent: Number.parseFloat((Math.random() * 0.8).toFixed(1)),
      },
      figma: {
        timeSpent: figmaTime,
        designs: figmaTime > 0 ? Math.floor(Math.random() * 2) + 1 : 0,
      },
      study: {
        total: Number.parseFloat(studyTime.toFixed(1)),
        subjects: {
          "CSE 355": Number.parseFloat((Math.random() * 2).toFixed(1)),
          "MAT 343": Number.parseFloat((Math.random() * 1.5).toFixed(1)),
          "ENG 302": Number.parseFloat((Math.random() * 1).toFixed(1)),
          "PHY 121": Number.parseFloat((Math.random() * 1.5).toFixed(1)),
        },
      },
      assignments: {
        completed: Math.floor(Math.random() * 3),
        timeSpent: Number.parseFloat((Math.random() * 3).toFixed(1)),
      },
      sleep: {
        hours: Number.parseFloat(sleepHours.toFixed(1)),
        quality: sleepHours > 7.5 ? "Good" : sleepHours > 6 ? "Average" : "Poor",
      },
      mood: {
        overall: mood,
        energy: Math.random() > 0.3 ? "high" : "low",
        stress: Math.random() > 0.6 ? "low" : "high",
        notes: "",
      },
      events: events,
    })
  }

  return monthData
}

// Generate daily events with prioritization
const generateDailyEvents = (date, isWeekend) => {
  const events = []
  const dayOfWeek = date.getDay()
  const dayOfMonth = date.getDate()

  // Regular classes (weekdays only)
  if (!isWeekend) {
    // Monday, Wednesday, Friday
    if (dayOfWeek === 1 || dayOfWeek === 3 || dayOfWeek === 5) {
      events.push({
        id: `class-cse-${date.getTime()}`,
        title: "CSE 355 Lecture",
        type: "class",
        startTime: "09:00",
        endTime: "10:15",
        location: "CAVC 351",
        priority: "high",
      })
      events.push({
        id: `class-eng-${date.getTime()}`,
        title: "ENG 302 Class",
        type: "class",
        startTime: "13:30",
        endTime: "14:45",
        location: "LL 14",
        priority: "high",
      })
    }

    // Tuesday, Thursday
    if (dayOfWeek === 2 || dayOfWeek === 4) {
      events.push({
        id: `class-mat-${date.getTime()}`,
        title: "MAT 343 Lecture",
        type: "class",
        startTime: "10:30",
        endTime: "11:45",
        location: "PSH 356",
        priority: "high",
      })
      events.push({
        id: `class-phy-${date.getTime()}`,
        title: "PHY 121 Lab",
        type: "class",
        startTime: "15:00",
        endTime: "16:50",
        location: "PSF 101",
        priority: "high",
      })
    }
  }

  // Assignments (randomly distributed)
  if (Math.random() > 0.7) {
    const dueDate = Math.random() > 0.5
    events.push({
      id: `assignment-${date.getTime()}`,
      title: `${["CSE 355", "MAT 343", "ENG 302", "PHY 121"][Math.floor(Math.random() * 4)]} ${["Assignment", "Project", "Paper", "Quiz"][Math.floor(Math.random() * 4)]}`,
      type: "assignment",
      dueDate: dueDate,
      dueTime: dueDate ? "23:59" : null,
      priority: Math.random() > 0.6 ? "high" : Math.random() > 0.3 ? "medium" : "low",
    })
  }

  // Study sessions
  if (Math.random() > 0.4) {
    events.push({
      id: `study-${date.getTime()}`,
      title: `Study ${["CSE 355", "MAT 343", "ENG 302", "PHY 121"][Math.floor(Math.random() * 4)]}`,
      type: "study",
      startTime: `${Math.floor(Math.random() * 5) + 14}:${Math.random() > 0.5 ? "00" : "30"}`,
      endTime: `${Math.floor(Math.random() * 2) + 16}:${Math.random() > 0.5 ? "00" : "30"}`,
      location: ["Library", "Home", "Study Room", "Coffee Shop"][Math.floor(Math.random() * 4)],
      priority: Math.random() > 0.5 ? "medium" : "low",
    })
  }

  // Club activities (twice a week)
  if ((dayOfWeek === 2 || dayOfWeek === 4) && Math.random() > 0.5) {
    events.push({
      id: `club-${date.getTime()}`,
      title: ["Robotics Club", "AI Society", "Entrepreneurship Club", "Chess Club"][Math.floor(Math.random() * 4)],
      type: "club",
      startTime: "18:00",
      endTime: "19:30",
      location: ["ISTB4 240", "MU 241", "CAVC 351", "PSH 356"][Math.floor(Math.random() * 4)],
      priority: "medium",
    })
  }

  // Hackathons (once a month)
  if (dayOfMonth === 15 || dayOfMonth === 16) {
    events.push({
      id: `hackathon-${date.getTime()}`,
      title: "ASU Innovation Hackathon",
      type: "hackathon",
      startTime: isWeekend ? "09:00" : "18:00",
      endTime: isWeekend ? "21:00" : "22:00",
      location: "Sun Devil Fitness Complex",
      priority: "medium",
      multiDay: dayOfMonth === 15,
    })
  }

  // Hikes (weekends only)
  if (isWeekend && Math.random() > 0.7) {
    events.push({
      id: `hike-${date.getTime()}`,
      title: ["Camelback Mountain", "South Mountain", "Papago Park", "Piestewa Peak"][Math.floor(Math.random() * 4)],
      type: "hike",
      startTime: "07:00",
      endTime: "10:00",
      priority: "low",
    })
  }

  // Seminars (random)
  if (Math.random() > 0.85) {
    events.push({
      id: `seminar-${date.getTime()}`,
      title: ["Research Symposium", "Career Workshop", "Industry Talk", "Graduate School Info Session"][
        Math.floor(Math.random() * 4)
      ],
      type: "seminar",
      startTime: `${Math.floor(Math.random() * 4) + 13}:00`,
      endTime: `${Math.floor(Math.random() * 2) + 15}:00`,
      location: ["Memorial Union", "Student Pavilion", "ISTB4", "CAVC"][Math.floor(Math.random() * 4)],
      priority: Math.random() > 0.5 ? "medium" : "low",
    })
  }

  // Meetings
  if (!isWeekend && Math.random() > 0.7) {
    events.push({
      id: `meeting-${date.getTime()}`,
      title: ["Advisor Meeting", "Project Team Meeting", "TA Office Hours", "Study Group"][
        Math.floor(Math.random() * 4)
      ],
      type: "meeting",
      startTime: `${Math.floor(Math.random() * 6) + 12}:${Math.random() > 0.5 ? "00" : "30"}`,
      endTime: `${Math.floor(Math.random() * 2) + 14}:${Math.random() > 0.5 ? "00" : "30"}`,
      location: ["BYENG 210", "Online", "Library", "MU"][Math.floor(Math.random() * 4)],
      priority: Math.random() > 0.6 ? "high" : "medium",
    })
  }

  // Workout
  if (Math.random() > 0.6) {
    events.push({
      id: `workout-${date.getTime()}`,
      title: ["Gym Session", "Run", "Yoga", "Basketball"][Math.floor(Math.random() * 4)],
      type: "workout",
      startTime: Math.random() > 0.5 ? "07:00" : "17:00",
      endTime: Math.random() > 0.5 ? "08:00" : "18:00",
      location: Math.random() > 0.5 ? "SDFC" : "Outdoor",
      priority: "low",
    })
  }

  // Social/Entertainment
  if (isWeekend || Math.random() > 0.8) {
    events.push({
      id: `social-${date.getTime()}`,
      title: ["Movie Night", "Dinner with Friends", "Game Night", "Concert"][Math.floor(Math.random() * 4)],
      type: "entertainment",
      startTime: "19:00",
      endTime: "22:00",
      priority: "low",
    })
  }

  // Sort events by priority and time
  return events.sort((a, b) => {
    const priorityOrder = { high: 0, medium: 1, low: 2 }
    if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    }
    return a.startTime?.localeCompare(b.startTime || "23:59") || 0
  })
}

const monthlyData = generateMonthlyData()

// Calculate aggregated data
const calculateAggregates = (data) => {
  return {
    leetcode: {
      totalTime: Number.parseFloat(data.reduce((sum, day) => sum + day.leetcode.timeSpent, 0).toFixed(1)),
      totalProblems: data.reduce((sum, day) => sum + day.leetcode.problems, 0),
      avgTimePerDay: Number.parseFloat(
        (data.reduce((sum, day) => sum + day.leetcode.timeSpent, 0) / data.length).toFixed(1),
      ),
      streak: 5, // Simulated streak
      mostActive: {
        day: "Saturday",
        problems: 8,
      },
    },
    study: {
      totalTime: Number.parseFloat(data.reduce((sum, day) => sum + day.study.total, 0).toFixed(1)),
      avgTimePerDay: Number.parseFloat((data.reduce((sum, day) => sum + day.study.total, 0) / data.length).toFixed(1)),
      bySubject: {
        "CSE 355": Number.parseFloat(data.reduce((sum, day) => sum + day.study.subjects["CSE 355"], 0).toFixed(1)),
        "MAT 343": Number.parseFloat(data.reduce((sum, day) => sum + day.study.subjects["MAT 343"], 0).toFixed(1)),
        "ENG 302": Number.parseFloat(data.reduce((sum, day) => sum + day.study.subjects["ENG 302"], 0).toFixed(1)),
        "PHY 121": Number.parseFloat(data.reduce((sum, day) => sum + day.study.subjects["PHY 121"], 0).toFixed(1)),
      },
    },
    sleep: {
      avgHours: Number.parseFloat((data.reduce((sum, day) => sum + day.sleep.hours, 0) / data.length).toFixed(1)),
      goodNights: data.filter((day) => day.sleep.quality === "Good").length,
      poorNights: data.filter((day) => day.sleep.quality === "Poor").length,
    },
    mood: {
      happy: data.filter((day) => day.mood.overall === "happy").length,
      neutral: data.filter((day) => day.mood.overall === "neutral").length,
      sad: data.filter((day) => day.mood.overall === "sad").length,
      highStressDays: data.filter((day) => day.mood.stress === "high").length,
    },
    github: {
      totalCommits: data.reduce((sum, day) => sum + day.github.commits, 0),
      totalPRs: data.reduce((sum, day) => sum + day.github.pullRequests, 0),
      totalIssues: data.reduce((sum, day) => sum + day.github.issues, 0),
      activeDays: data.filter((day) => day.github.commits > 0).length,
    },
    codepen: {
      totalProjects: data.reduce((sum, day) => sum + (day.codepen?.projects || 0), 0),
      totalTime: Number.parseFloat(data.reduce((sum, day) => sum + (day.codepen?.timeSpent || 0), 0).toFixed(1)),
    },
    figma: {
      totalTime: Number.parseFloat(data.reduce((sum, day) => sum + (day.figma?.timeSpent || 0), 0).toFixed(1)),
      totalDesigns: data.reduce((sum, day) => sum + (day.figma?.designs || 0), 0),
    },
    events: {
      total: data.reduce((sum, day) => sum + day.events.length, 0),
      byType: {
        class: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "class").length, 0),
        assignment: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "assignment").length, 0),
        study: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "study").length, 0),
        club: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "club").length, 0),
        hackathon: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "hackathon").length, 0),
        hike: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "hike").length, 0),
        seminar: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "seminar").length, 0),
        meeting: data.reduce((sum, day) => sum + day.events.filter((e) => e.type === "meeting").length, 0),
      },
      byPriority: {
        high: data.reduce((sum, day) => sum + day.events.filter((e) => e.priority === "high").length, 0),
        medium: data.reduce((sum, day) => sum + day.events.filter((e) => e.priority === "medium").length, 0),
        low: data.reduce((sum, day) => sum + day.events.filter((e) => e.priority === "low").length, 0),
      },
    },
  }
}

const aggregatedData = calculateAggregates(monthlyData)

// Get color based on time intensity
const getTimeIntensityColor = (value, max, colorScheme = "default") => {
  const intensity = Math.min(value / max, 1)

  if (colorScheme === "study") {
    // Purple to blue gradient for study time
    return `rgba(99, 102, 241, ${0.2 + intensity * 0.8})`
  } else if (colorScheme === "coding") {
    // Green to teal gradient for coding
    return `rgba(16, 185, 129, ${0.2 + intensity * 0.8})`
  } else if (colorScheme === "sleep") {
    // Blue gradient for sleep
    return `rgba(59, 130, 246, ${0.2 + intensity * 0.8})`
  } else {
    // Default ASU maroon gradient
    return `rgba(140, 29, 64, ${0.2 + intensity * 0.8})`
  }
}

const getMoodIcon = (mood) => {
  switch (mood) {
    case "happy":
      return <Smile className="text-green-500" />
    case "neutral":
      return <Meh className="text-yellow-500" />
    case "sad":
      return <Frown className="text-red-500" />
    default:
      return <Smile className="text-gray-500" />
  }
}

const getPriorityBadge = (priority) => {
  switch (priority) {
    case "high":
      return <Badge className="bg-red-500 text-white">High</Badge>
    case "medium":
      return <Badge className="bg-amber-500 text-white">Medium</Badge>
    case "low":
      return <Badge className="bg-green-500 text-white">Low</Badge>
    default:
      return null
  }
}

const getEventIcon = (type) => {
  const eventType = eventTypes[type]
  if (!eventType) return <Activity className="h-4 w-4" />

  const IconComponent = eventType.icon
  return <IconComponent className="h-4 w-4" style={{ color: eventType.color }} />
}

export default function ActivityTracker() {
  const [activeTab, setActiveTab] = useState("coding")
  const [timeRange, setTimeRange] = useState("month")
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth())
  const [selectedDate, setSelectedDate] = useState(new Date())

  // Get last 7 days of data for weekly view
  const weeklyData = monthlyData.slice(-7)

  // Format date for display
  const formatDate = (date) => {
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  // Get events for selected date
  const selectedDateEvents =
    monthlyData.find(
      (day) => day.date.getDate() === selectedDate.getDate() && day.date.getMonth() === selectedDate.getMonth(),
    )?.events || []

  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-asu-maroon flex items-center">
              <Activity className="h-5 w-5 mr-2 text-asu-gold" />
              Activity Insights
            </CardTitle>
            <CardDescription>Track your productivity and wellness</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[120px] border-asu-maroon/20">
                <SelectValue placeholder="Time Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="week">Last 7 Days</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="semester">Semester</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="outline" className="bg-green-100 text-green-800 border-green-500">
              <Award className="h-3 w-3 mr-1" />
              Productive Month
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {/* Coding Platforms Overview */}
        <div className="grid grid-cols-6 gap-2 mb-6">
          <Card className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 border-none shadow-sm flex items-center p-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-black flex items-center justify-center">
                <Github className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-xs font-medium">GitHub</p>
                <p className="text-lg font-bold">{aggregatedData.github.totalCommits}</p>
                <p className="text-[10px] text-muted-foreground">commits</p>
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-none shadow-sm flex items-center p-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center">
                <Code className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-xs font-medium">LeetCode</p>
                <p className="text-lg font-bold">{aggregatedData.leetcode.totalProblems}</p>
                <p className="text-[10px] text-muted-foreground">problems</p>
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 border-none shadow-sm flex items-center p-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center">
                <Linkedin className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-xs font-medium">LinkedIn</p>
                <p className="text-lg font-bold">
                  {monthlyData.reduce((sum, day) => sum + day.linkedin.connections, 0)}
                </p>
                <p className="text-[10px] text-muted-foreground">connections</p>
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 border-none shadow-sm flex items-center p-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-purple-600 flex items-center justify-center">
                <Codepen className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-xs font-medium">CodePen</p>
                <p className="text-lg font-bold">{aggregatedData.codepen.totalProjects}</p>
                <p className="text-[10px] text-muted-foreground">projects</p>
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-pink-50 to-pink-100 dark:from-pink-900/20 dark:to-pink-800/20 border-none shadow-sm flex items-center p-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-pink-600 flex items-center justify-center">
                <Figma className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-xs font-medium">Figma</p>
                <p className="text-lg font-bold">{aggregatedData.figma.totalDesigns}</p>
                <p className="text-[10px] text-muted-foreground">designs</p>
              </div>
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20 border-none shadow-sm flex items-center p-2">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-green-600 flex items-center justify-center">
                <BookOpen className="h-4 w-4 text-white" />
              </div>
              <div>
                <p className="text-xs font-medium">Study</p>
                <p className="text-lg font-bold">{aggregatedData.study.totalTime}</p>
                <p className="text-[10px] text-muted-foreground">hours</p>
              </div>
            </div>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-5 mb-4">
            <TabsTrigger value="coding" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Code className="h-4 w-4 mr-2" />
              Coding
            </TabsTrigger>
            <TabsTrigger value="study" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <BookOpen className="h-4 w-4 mr-2" />
              Study
            </TabsTrigger>
            <TabsTrigger value="events" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Calendar className="h-4 w-4 mr-2" />
              Events
            </TabsTrigger>
            <TabsTrigger value="wellness" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Brain className="h-4 w-4 mr-2" />
              Wellness
            </TabsTrigger>
            <TabsTrigger value="sleep" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <Moon className="h-4 w-4 mr-2" />
              Sleep
            </TabsTrigger>
          </TabsList>

          <TabsContent value="coding" className="space-y-4">
            {/* Coding Activity Heatmap */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg flex items-center">
                    <BarChart className="h-4 w-4 mr-2 text-asu-maroon" />
                    Coding Activity
                  </CardTitle>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <span className="mr-2">Total Commits: {aggregatedData.github.totalCommits}</span>
                    <span>Active Days: {aggregatedData.github.activeDays}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-medium">GitHub Contribution Activity</span>
                    <div className="flex items-center gap-1 text-xs">
                      <div className="w-3 h-3 bg-green-100 rounded-sm"></div>
                      <div className="w-3 h-3 bg-green-300 rounded-sm"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-sm"></div>
                      <div className="w-3 h-3 bg-green-700 rounded-sm"></div>
                      <span className="ml-1">Less → More</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-52 gap-1 h-20">
                    {monthlyData.map((day, i) => (
                      <div
                        key={i}
                        className={`w-3 h-3 rounded-sm ${
                          day.github.commits === 0
                            ? "bg-gray-100"
                            : day.github.commits < 2
                              ? "bg-green-100"
                              : day.github.commits < 4
                                ? "bg-green-300"
                                : day.github.commits < 6
                                  ? "bg-green-500"
                                  : "bg-green-700"
                        }`}
                        title={`${formatDate(day.date)}: ${day.github.commits} commits`}
                      />
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  {/* LeetCode */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <Code className="h-4 w-4 mr-2" />
                        LeetCode
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Time</span>
                          <span className="font-medium">{aggregatedData.leetcode.totalTime}h</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Problems Solved</span>
                          <span className="font-medium">{aggregatedData.leetcode.totalProblems}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Current Streak</span>
                          <Badge className="bg-green-100 text-green-800 border-green-500">
                            {aggregatedData.leetcode.streak} days
                          </Badge>
                        </div>

                        <div className="pt-2">
                          <p className="text-sm font-medium mb-2">Daily Activity</p>
                          <div className="flex items-end h-24 gap-1">
                            {(timeRange === "week" ? weeklyData : monthlyData.slice(-14)).map((day, i) => (
                              <div key={i} className="flex-1 flex flex-col items-center">
                                <div
                                  className="w-full rounded-t"
                                  style={{
                                    height: `${Math.min(day.leetcode.timeSpent * 20, 100)}%`,
                                    backgroundColor: colorPalette.coding.green,
                                    opacity: 0.2 + (day.leetcode.timeSpent / 3) * 0.8,
                                  }}
                                  title={`${formatDate(day.date)}: ${day.leetcode.timeSpent}h, ${day.leetcode.problems} problems`}
                                />
                                <span className="text-[10px] mt-1 rotate-45 origin-left">{day.date.getDate()}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* GitHub */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <Github className="h-4 w-4 mr-2" />
                        GitHub
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Total Commits</span>
                          <span className="font-medium">{aggregatedData.github.totalCommits}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Pull Requests</span>
                          <span className="font-medium">{aggregatedData.github.totalPRs}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm">Active Days</span>
                          <Badge className="bg-green-100 text-green-800 border-green-500">
                            {aggregatedData.github.activeDays} days
                          </Badge>
                        </div>

                        <div className="pt-2">
                          <p className="text-sm font-medium mb-2">Commit Activity</p>
                          <div className="flex items-end h-24 gap-1">
                            {(timeRange === "week" ? weeklyData : monthlyData.slice(-14)).map((day, i) => (
                              <div key={i} className="flex-1 flex flex-col items-center">
                                <div
                                  className="w-full rounded-t"
                                  style={{
                                    height: `${Math.min(day.github.commits * 12, 100)}%`,
                                    backgroundColor: colorPalette.coding.blue,
                                    opacity: 0.2 + (day.github.commits / 8) * 0.8,
                                  }}
                                  title={`${formatDate(day.date)}: ${day.github.commits} commits`}
                                />
                                <span className="text-[10px] mt-1 rotate-45 origin-left">{day.date.getDate()}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Other Platforms */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Other Platforms</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm flex items-center">
                              <Figma className="h-3 w-3 mr-1 text-pink-500" /> Figma
                            </span>
                            <span className="text-sm font-medium">{aggregatedData.figma.totalTime}h</span>
                          </div>
                          <div className="h-2 rounded-full bg-gray-100">
                            <div
                              className="h-2 rounded-full bg-pink-500"
                              style={{ width: `${Math.min(aggregatedData.figma.totalTime * 10, 100)}%` }}
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm flex items-center">
                              <Codepen className="h-3 w-3 mr-1 text-purple-500" /> CodePen
                            </span>
                            <span className="text-sm font-medium">{aggregatedData.codepen.totalTime}h</span>
                          </div>
                          <div className="h-2 rounded-full bg-gray-100">
                            <div
                              className="h-2 rounded-full bg-purple-500"
                              style={{ width: `${Math.min(aggregatedData.codepen.totalTime * 10, 100)}%` }}
                            />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm flex items-center">
                              <Linkedin className="h-3 w-3 mr-1 text-blue-500" /> LinkedIn
                            </span>
                            <span className="text-sm font-medium">
                              {monthlyData.reduce((sum, day) => sum + day.linkedin.timeSpent, 0).toFixed(1)}h
                            </span>
                          </div>
                          <div className="h-2 rounded-full bg-gray-100">
                            <div
                              className="h-2 rounded-full bg-blue-500"
                              style={{
                                width: `${Math.min(monthlyData.reduce((sum, day) => sum + day.linkedin.timeSpent, 0) * 10, 100)}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="study" className="space-y-4">
            {/* Study Time Distribution */}
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg flex items-center">
                    <BookOpen className="h-4 w-4 mr-2 text-asu-maroon" />
                    Study Time Distribution
                  </CardTitle>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <span className="mr-2">Total: {aggregatedData.study.totalTime}h</span>
                    <span>Daily Avg: {aggregatedData.study.avgTimePerDay}h</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Subject Distribution */}
                  <div>
                    <p className="text-sm font-medium mb-4">Time by Subject</p>
                    <div className="space-y-4">
                      {Object.entries(aggregatedData.study.bySubject).map(([subject, hours], index) => (
                        <div key={subject} className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>{subject}</span>
                            <span>{hours}h</span>
                          </div>
                          <div className="h-2 rounded-full bg-gray-100">
                            <div
                              className="h-2 rounded-full"
                              style={{
                                width: `${(hours / aggregatedData.study.totalTime) * 100}%`,
                                backgroundColor: [
                                  colorPalette.study.indigo,
                                  colorPalette.study.violet,
                                  colorPalette.study.fuchsia,
                                  colorPalette.coding.teal,
                                ][index],
                                opacity: 0.2 + (hours / 30) * 0.8,
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Daily Study Time */}
                  <div>
                    <p className="text-sm font-medium mb-4">Daily Study Time</p>
                    <div className="flex items-end h-40 gap-1">
                      {(timeRange === "week" ? weeklyData : monthlyData.slice(-14)).map((day, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center">
                          <div
                            className="w-full rounded-t"
                            style={{
                              height: `${Math.min(day.study.total * 10, 100)}%`,
                              backgroundColor: colorPalette.study.indigo,
                              opacity: 0.2 + (day.study.total / 8) * 0.8,
                            }}
                            title={`${formatDate(day.date)}: ${day.study.total}h`}
                          />
                          <span className="text-[10px] mt-1 rotate-45 origin-left">{day.date.getDate()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Assignments */}
                <div className="mt-8">
                  <p className="text-sm font-medium mb-4">Assignment Completion</p>
                  <div className="grid grid-cols-7 gap-2">
                    {(timeRange === "week" ? weeklyData : monthlyData.slice(-7)).map((day, i) => (
                      <Card key={i} className="p-2 border-none bg-gray-50">
                        <div className="text-center">
                          <p className="text-xs font-medium">{formatDate(day.date)}</p>
                          <div className="my-2">
                            {day.assignments.completed > 0 ? (
                              <div className="flex justify-center">
                                <Badge className="bg-green-100 text-green-800">
                                  {day.assignments.completed} completed
                                </Badge>
                              </div>
                            ) : (
                              <div className="h-6 flex items-center justify-center">
                                <span className="text-xs text-gray-400">-</span>
                              </div>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">{day.assignments.timeSpent}h spent</p>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="events" className="space-y-4">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-lg flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-asu-maroon" />
                    Events & Activities
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-red-100 text-red-800 border-red-500">
                      {aggregatedData.events.byPriority.high} High Priority
                    </Badge>
                    <Badge className="bg-amber-100 text-amber-800 border-amber-500">
                      {aggregatedData.events.byPriority.medium} Medium
                    </Badge>
                    <Badge className="bg-green-100 text-green-800 border-green-500">
                      {aggregatedData.events.byPriority.low} Low
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Event Calendar */}
                  <div className="md:col-span-2">
                    <p className="text-sm font-medium mb-4">Event Calendar</p>
                    <div className="grid grid-cols-7 gap-1">
                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                        <div key={day} className="text-center text-xs font-medium text-muted-foreground">
                          {day}
                        </div>
                      ))}

                      {Array.from(
                        {
                          length: new Date(
                            monthlyData[0].date.getFullYear(),
                            monthlyData[0].date.getMonth(),
                            1,
                          ).getDay(),
                        },
                        (_, i) => (
                          <div key={`empty-${i}`} className="h-20"></div>
                        ),
                      )}

                      {monthlyData.map((day, i) => (
                        <div
                          key={i}
                          className={`h-20 border rounded-md p-1 overflow-hidden text-xs cursor-pointer hover:bg-gray-50 ${
                            selectedDate.getDate() === day.date.getDate() &&
                            selectedDate.getMonth() === day.date.getMonth()
                              ? "border-asu-maroon bg-asu-maroon/5"
                              : "border-gray-200"
                          }`}
                          onClick={() => setSelectedDate(day.date)}
                        >
                          <div className="font-medium">{day.date.getDate()}</div>
                          <div className="space-y-1 mt-1">
                            {day.events.slice(0, 3).map((event, j) => (
                              <div
                                key={j}
                                className="flex items-center gap-1 truncate"
                                style={{ color: eventTypes[event.type]?.color || "inherit" }}
                              >
                                {getEventIcon(event.type)}
                                <span className="truncate text-[8px]">{event.title}</span>
                              </div>
                            ))}
                            {day.events.length > 3 && (
                              <div className="text-[8px] text-muted-foreground">+{day.events.length - 3} more</div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Event Details */}
                  <div className="md:col-span-1">
                    <div className="flex items-center justify-between mb-4">
                      <p className="text-sm font-medium">
                        {selectedDate.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" })}
                      </p>
                      <Badge className="bg-asu-maroon text-white">{selectedDateEvents.length} Events</Badge>
                    </div>

                    <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2">
                      {selectedDateEvents.length > 0 ? (
                        selectedDateEvents.map((event, i) => (
                          <Card key={i} className="p-3 border shadow-sm">
                            <div className="flex items-start justify-between">
                              <div className="flex items-start gap-2">
                                <div className="mt-0.5">{getEventIcon(event.type)}</div>
                                <div>
                                  <p className="font-medium text-sm">{event.title}</p>
                                  {event.startTime && (
                                    <p className="text-xs text-muted-foreground">
                                      {event.startTime} - {event.endTime}
                                    </p>
                                  )}
                                  {event.location && <p className="text-xs text-muted-foreground">{event.location}</p>}
                                  {event.dueDate && (
                                    <p className="text-xs text-red-500 font-medium">
                                      Due today {event.dueTime && `at ${event.dueTime}`}
                                    </p>
                                  )}
                                </div>
                              </div>
                              <div>{getPriorityBadge(event.priority)}</div>
                            </div>
                          </Card>
                        ))
                      ) : (
                        <div className="text-center py-8 text-muted-foreground">No events scheduled for this day</div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Event Type Distribution */}
                <div className="mt-8">
                  <p className="text-sm font-medium mb-4">Event Type Distribution</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {Object.entries(aggregatedData.events.byType).map(
                      ([type, count]) =>
                        count > 0 && (
                          <Card key={type} className="p-3 border shadow-sm">
                            <div className="flex items-center gap-2">
                              <div
                                className="h-8 w-8 rounded-full flex items-center justify-center"
                                style={{ backgroundColor: `${eventTypes[type]?.color}20` || "#f3f4f6" }}
                              >
                                {getEventIcon(type)}
                              </div>
                              <div>
                                <p className="font-medium text-sm capitalize">{type}</p>
                                <p className="text-xs text-muted-foreground">{count} events</p>
                              </div>
                            </div>
                          </Card>
                        ),
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="wellness">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <Brain className="h-4 w-4 mr-2 text-asu-maroon" />
                  Mood & Wellness Tracker
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Mood Distribution */}
                  <div>
                    <p className="text-sm font-medium mb-4">Monthly Mood Distribution</p>
                    <div className="flex items-center justify-center h-48">
                      <div className="flex gap-4 items-end">
                        <div className="flex flex-col items-center">
                          <div className="text-center mb-2">
                            <Smile className="h-6 w-6 text-green-500 mx-auto" />
                            <span className="text-sm font-medium">Happy</span>
                          </div>
                          <div
                            className="w-16 bg-green-500 rounded-t-md"
                            style={{ height: `${(aggregatedData.mood.happy / monthlyData.length) * 100}%` }}
                          ></div>
                          <span className="text-sm mt-2">{aggregatedData.mood.happy} days</span>
                        </div>

                        <div className="flex flex-col items-center">
                          <div className="text-center mb-2">
                            <Meh className="h-6 w-6 text-yellow-500 mx-auto" />
                            <span className="text-sm font-medium">Neutral</span>
                          </div>
                          <div
                            className="w-16 bg-yellow-500 rounded-t-md"
                            style={{ height: `${(aggregatedData.mood.neutral / monthlyData.length) * 100}%` }}
                          ></div>
                          <span className="text-sm mt-2">{aggregatedData.mood.neutral} days</span>
                        </div>

                        <div className="flex flex-col items-center">
                          <div className="text-center mb-2">
                            <Frown className="h-6 w-6 text-red-500 mx-auto" />
                            <span className="text-sm font-medium">Sad</span>
                          </div>
                          <div
                            className="w-16 bg-red-500 rounded-t-md"
                            style={{ height: `${(aggregatedData.mood.sad / monthlyData.length) * 100}%` }}
                          ></div>
                          <span className="text-sm mt-2">{aggregatedData.mood.sad} days</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Daily Mood Tracker */}
                  <div>
                    <p className="text-sm font-medium mb-4">Daily Mood Pattern</p>
                    <div className="grid grid-cols-7 gap-2">
                      {(timeRange === "week" ? weeklyData : monthlyData.slice(-7)).map((day, i) => (
                        <Card key={i} className="p-2 border-none bg-gray-50">
                          <div className="text-center">
                            <p className="text-xs font-medium">{formatDate(day.date)}</p>
                            <div className="my-2 flex justify-center">{getMoodIcon(day.mood.overall)}</div>
                            <div className="flex justify-center gap-1 mt-1">
                              {day.mood.energy === "high" ? (
                                <Badge className="text-xs px-1 py-0 h-4 bg-green-100 text-green-800">
                                  <Zap className="h-2 w-2 mr-1" />
                                  Energy
                                </Badge>
                              ) : null}
                              {day.mood.stress === "high" ? (
                                <Badge className="text-xs px-1 py-0 h-4 bg-red-100 text-red-800">Stress</Badge>
                              ) : null}
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>

                    <div className="mt-6">
                      <p className="text-sm font-medium mb-2">Mood Factors</p>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>Stress Level</span>
                            <span>{aggregatedData.mood.highStressDays} high stress days</span>
                          </div>
                          <div className="h-2 rounded-full bg-gray-100">
                            <div
                              className="h-2 rounded-full bg-red-500"
                              style={{ width: `${(aggregatedData.mood.highStressDays / monthlyData.length) * 100}%` }}
                            />
                          </div>
                        </div>

                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>Energy Level</span>
                            <span>
                              {monthlyData.filter((day) => day.mood.energy === "high").length} high energy days
                            </span>
                          </div>
                          <div className="h-2 rounded-full bg-gray-100">
                            <div
                              className="h-2 rounded-full bg-green-500"
                              style={{
                                width: `${(monthlyData.filter((day) => day.mood.energy === "high").length / monthlyData.length) * 100}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Mood vs. Productivity Correlation */}
                <div className="mt-8">
                  <p className="text-sm font-medium mb-4">Mood & Productivity Correlation</p>
                  <div className="overflow-x-auto">
                    <div className="min-w-[600px]">
                      <div className="flex items-end h-40 gap-1">
                        {(timeRange === "week" ? weeklyData : monthlyData.slice(-14)).map((day, i) => (
                          <div key={i} className="flex-1 flex flex-col items-center">
                            <div className="flex flex-col items-center gap-1">
                              <div
                                className={`w-full rounded-t ${
                                  day.mood.overall === "happy"
                                    ? "bg-green-500"
                                    : day.mood.overall === "neutral"
                                      ? "bg-yellow-500"
                                      : "bg-red-500"
                                }`}
                                style={{ height: "8px" }}
                              />
                              <div
                                className="w-full rounded-t bg-asu-maroon/80"
                                style={{
                                  height: `${Math.min((day.study.total + day.leetcode.timeSpent) * 8, 100)}%`,
                                }}
                                title={`${formatDate(day.date)}: ${day.study.total + day.leetcode.timeSpent}h total productive time`}
                              />
                            </div>
                            <span className="text-[10px] mt-1 rotate-45 origin-left">{day.date.getDate()}</span>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-center gap-8 mt-6 text-xs">
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
                          <span>Happy</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-yellow-500 rounded-full mr-1"></div>
                          <span>Neutral</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-red-500 rounded-full mr-1"></div>
                          <span>Sad</span>
                        </div>
                        <div className="flex items-center">
                          <div className="w-3 h-3 bg-asu-maroon rounded-full mr-1"></div>
                          <span>Productivity</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sleep">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <Moon className="h-4 w-4 mr-2 text-asu-maroon" />
                  Sleep Tracking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-none shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Average Sleep</p>
                          <p className="text-2xl font-bold text-blue-700">{aggregatedData.sleep.avgHours}h</p>
                        </div>
                        <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <Clock className="h-5 w-5 text-blue-700" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-green-50 to-green-100 border-none shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Good Sleep Nights</p>
                          <p className="text-2xl font-bold text-green-700">{aggregatedData.sleep.goodNights}</p>
                        </div>
                        <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                          <Smile className="h-5 w-5 text-green-700" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-red-50 to-red-100 border-none shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Poor Sleep Nights</p>
                          <p className="text-2xl font-bold text-red-700">{aggregatedData.sleep.poorNights}</p>
                        </div>
                        <div className="h-10 w-10 rounded-full bg-red-100 flex items-center justify-center">
                          <Frown className="h-5 w-5 text-red-700" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sleep Pattern Visualization */}
                <div className="mt-6">
                  <p className="text-sm font-medium mb-4">Sleep Duration Pattern</p>
                  <div className="flex items-end h-40 gap-1">
                    {(timeRange === "week" ? weeklyData : monthlyData.slice(-14)).map((day, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center">
                        <div
                          className="w-full rounded-t"
                          style={{
                            height: `${Math.min(day.sleep.hours * 8, 100)}%`,
                            backgroundColor: colorPalette.sleep.sky,
                            opacity: 0.2 + (day.sleep.hours / 9) * 0.8,
                          }}
                          title={`${formatDate(day.date)}: ${day.sleep.hours}h (${day.sleep.quality})`}
                        />
                        <span className="text-[10px] mt-1 rotate-45 origin-left">{day.date.getDate()}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-between mt-8">
                    <div className="text-xs text-muted-foreground">Recommended: 7-9 hours</div>
                    <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center">
                        <div
                          className="w-3 h-3 rounded-full mr-1"
                          style={{ backgroundColor: colorPalette.sleep.sky, opacity: 0.3 }}
                        ></div>
                        <span>Poor</span>
                      </div>
                      <div className="flex items-center">
                        <div
                          className="w-3 h-3 rounded-full mr-1"
                          style={{ backgroundColor: colorPalette.sleep.sky, opacity: 0.6 }}
                        ></div>
                        <span>Average</span>
                      </div>
                      <div className="flex items-center">
                        <div
                          className="w-3 h-3 rounded-full mr-1"
                          style={{ backgroundColor: colorPalette.sleep.sky, opacity: 0.9 }}
                        ></div>
                        <span>Good</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sleep Quality Calendar */}
                <div className="mt-8">
                  <p className="text-sm font-medium mb-4">Sleep Quality Calendar</p>
                  <div className="grid grid-cols-7 gap-2">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                      <div key={day} className="text-center text-xs font-medium text-muted-foreground">
                        {day}
                      </div>
                    ))}

                    {Array.from(
                      {
                        length: new Date(monthlyData[0].date.getFullYear(), monthlyData[0].date.getMonth(), 1).getDay(),
                      },
                      (_, i) => (
                        <div key={`empty-${i}`} className="h-12"></div>
                      ),
                    )}

                    {monthlyData.map((day, i) => (
                      <Card
                        key={i}
                        className={`h-12 flex items-center justify-center p-1 border-none ${
                          day.sleep.quality === "Good"
                            ? "bg-blue-100"
                            : day.sleep.quality === "Average"
                              ? "bg-blue-50"
                              : "bg-red-50"
                        }`}
                      >
                        <div className="text-center">
                          <p className="text-xs font-medium">{day.date.getDate()}</p>
                          <p className="text-[10px] text-muted-foreground">{day.sleep.hours}h</p>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

