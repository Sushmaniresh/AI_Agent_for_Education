"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"

type TimeBlock = {
  id: string
  startTime: string
  endTime: string
  title: string
  location?: string
  type: "class" | "study" | "meeting" | "personal" | "deadline" | "club"
}

export default function DailyPlanner() {
  // Sample data - would come from your backend/API
  const timeBlocks: TimeBlock[] = [
    { id: "1", startTime: "08:00", endTime: "09:15", title: "CSE 355 Lecture", location: "CAVC 351", type: "class" },
    { id: "2", startTime: "09:30", endTime: "10:45", title: "MAT 343 Lecture", location: "PSH 356", type: "class" },
    {
      id: "3",
      startTime: "11:00",
      endTime: "12:30",
      title: "Study Session",
      location: "Hayden Library",
      type: "study",
    },
    {
      id: "4",
      startTime: "12:30",
      endTime: "13:30",
      title: "Lunch Break",
      location: "Memorial Union",
      type: "personal",
    },
    {
      id: "5",
      startTime: "14:00",
      endTime: "15:30",
      title: "Research Meeting",
      location: "BYENG 210",
      type: "meeting",
    },
    { id: "6", startTime: "16:00", endTime: "17:30", title: "Canvas Assignment Due", type: "deadline" },
    { id: "7", startTime: "18:00", endTime: "19:30", title: "Robotics Club", location: "ISTB4 240", type: "club" },
    { id: "8", startTime: "20:00", endTime: "21:30", title: "Project Work", location: "Home", type: "study" },
  ]

  const getTypeColor = (type: TimeBlock["type"]) => {
    switch (type) {
      case "class":
        return "bg-asu-maroon text-white"
      case "study":
        return "bg-green-600 text-white"
      case "meeting":
        return "bg-purple-600 text-white"
      case "personal":
        return "bg-yellow-500 text-white"
      case "deadline":
        return "bg-red-600 text-white"
      case "club":
        return "bg-blue-600 text-white"
      default:
        return "bg-gray-600 text-white"
    }
  }

  return (
    <Card className="border-t-4 border-t-asu-gold shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-gold/10 to-white dark:from-asu-gold/20 dark:to-transparent">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-asu-maroon">Daily Planner</CardTitle>
            <CardDescription>Your schedule for {new Date().toLocaleDateString()}</CardDescription>
          </div>
          <Button size="sm" variant="outline" className="border-asu-gold text-asu-maroon hover:bg-asu-gold/10">
            <PlusCircle className="h-4 w-4 mr-1" />
            Add Event
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[320px] pr-4">
          <div className="space-y-3">
            {timeBlocks.map((block) => (
              <div
                key={block.id}
                className="flex items-start space-x-3 p-3 rounded-md hover:bg-muted/50 border shadow-sm"
              >
                <div className="w-20 text-sm font-medium text-asu-maroon">
                  {block.startTime} - {block.endTime}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <p className="font-medium">{block.title}</p>
                    <Badge className={`${getTypeColor(block.type)}`}>
                      {block.type.charAt(0).toUpperCase() + block.type.slice(1)}
                    </Badge>
                  </div>
                  {block.location && <p className="text-xs text-muted-foreground mt-1">Location: {block.location}</p>}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

