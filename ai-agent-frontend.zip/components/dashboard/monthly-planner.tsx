"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { CalendarDays, PlusCircle } from "lucide-react"

type Event = {
  id: string
  date: Date
  title: string
  type: "assignment" | "exam" | "event" | "meeting" | "deadline" | "holiday"
  description?: string
}

export default function MonthlyPlanner() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Sample data - would come from your backend/API
  const events: Event[] = [
    {
      id: "1",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 10),
      title: "CSE 355 Midterm",
      type: "exam",
      description: "Covers chapters 1-5, bring calculator and student ID",
    },
    {
      id: "2",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 15),
      title: "Project Deadline",
      type: "deadline",
      description: "Final submission for CSE 340 project",
    },
    {
      id: "3",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 18),
      title: "Research Symposium",
      type: "event",
      description: "Fulton Schools Research Symposium at Memorial Union",
    },
    {
      id: "4",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 22),
      title: "Canvas Assignment Due",
      type: "assignment",
      description: "ENG 302 research paper due by 11:59 PM",
    },
    {
      id: "5",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 25),
      title: "Advisor Meeting",
      type: "meeting",
      description: "Discuss course selection for next semester",
    },
    {
      id: "6",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 5),
      title: "MAT 343 Quiz",
      type: "exam",
      description: "In-class quiz on linear transformations",
    },
    {
      id: "7",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 12),
      title: "Career Fair",
      type: "event",
      description: "Engineering Career Fair at Sun Devil Fitness Complex",
    },
    {
      id: "8",
      date: new Date(new Date().getFullYear(), new Date().getMonth(), 28),
      title: "Spring Break",
      type: "holiday",
      description: "No classes for the week",
    },
  ]

  const getTypeColor = (type: Event["type"]) => {
    switch (type) {
      case "assignment":
        return "bg-blue-600 text-white"
      case "exam":
        return "bg-red-600 text-white"
      case "event":
        return "bg-green-600 text-white"
      case "meeting":
        return "bg-purple-600 text-white"
      case "deadline":
        return "bg-yellow-600 text-white"
      case "holiday":
        return "bg-asu-gold text-asu-maroon"
      default:
        return "bg-gray-600 text-white"
    }
  }

  // Get events for the selected date
  const selectedDateEvents = events.filter((event) => date && event.date.toDateString() === date.toDateString())

  // Function to check if a date has events
  const hasEvents = (day: Date) => {
    return events.some((event) => event.date.toDateString() === day.toDateString())
  }

  return (
    <Card className="border-t-4 border-t-asu-gold shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-gold/10 to-white dark:from-asu-gold/20 dark:to-transparent">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-asu-maroon flex items-center">
              <CalendarDays className="h-5 w-5 mr-2 text-asu-gold" />
              Monthly Planner
            </CardTitle>
            <CardDescription>View and manage your monthly schedule</CardDescription>
          </div>
          <Button size="sm" variant="outline" className="border-asu-gold text-asu-maroon hover:bg-asu-gold/10">
            <PlusCircle className="h-4 w-4 mr-1" />
            Add Event
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-7 gap-4">
          <div className="md:col-span-4">
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
              modifiers={{
                hasEvent: (date) => hasEvents(date),
              }}
              modifiersClassNames={{
                hasEvent: "font-bold bg-asu-maroon text-white",
              }}
            />
          </div>
          <div className="md:col-span-3">
            <div className="bg-asu-maroon text-white p-3 rounded-t-md">
              <h3 className="font-medium">
                {date
                  ? date.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })
                  : "Select a date"}
              </h3>
            </div>
            <div className="border border-t-0 rounded-b-md p-3 max-h-[250px] overflow-auto">
              {selectedDateEvents.length > 0 ? (
                <div className="space-y-3">
                  {selectedDateEvents.map((event) => (
                    <div key={event.id} className="p-3 rounded-md border shadow-sm">
                      <div className="flex justify-between items-start">
                        <p className="font-medium">{event.title}</p>
                        <Badge className={`${getTypeColor(event.type)}`}>
                          {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                        </Badge>
                      </div>
                      {event.description && <p className="text-sm text-muted-foreground mt-1">{event.description}</p>}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No events scheduled for this day.</p>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

