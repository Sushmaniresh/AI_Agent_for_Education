"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Edit2, Trash2, Target, Award, TrendingUp } from "lucide-react"

type Goal = {
  id: string
  title: string
  description: string
  progress: number
  category: "academic" | "career" | "personal" | "research"
  deadline?: string
}

export default function SemesterGoals() {
  const [goals, setGoals] = useState<Goal[]>([
    {
      id: "1",
      title: "Maintain 3.8+ GPA",
      description: "Focus on core classes and maintain consistent study schedule",
      progress: 75,
      category: "academic",
      deadline: "End of semester",
    },
    {
      id: "2",
      title: "Complete Research Project",
      description: "Finish data collection and analysis for senior thesis",
      progress: 40,
      category: "research",
      deadline: "November 15",
    },
    {
      id: "3",
      title: "Secure Summer Internship",
      description: "Apply to at least 15 companies and prepare for interviews",
      progress: 60,
      category: "career",
      deadline: "March 1",
    },
    {
      id: "4",
      title: "Learn Machine Learning",
      description: "Complete online course and build 2 projects for portfolio",
      progress: 25,
      category: "academic",
    },
    {
      id: "5",
      title: "Join Research Lab",
      description: "Connect with professors and apply for undergraduate research position",
      progress: 50,
      category: "research",
    },
    {
      id: "6",
      title: "Improve Presentation Skills",
      description: "Join Toastmasters and practice public speaking",
      progress: 30,
      category: "personal",
    },
  ])

  const [newGoal, setNewGoal] = useState<Omit<Goal, "id">>({
    title: "",
    description: "",
    progress: 0,
    category: "academic",
  })

  const [editingGoal, setEditingGoal] = useState<Goal | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  const addGoal = () => {
    if (newGoal.title.trim()) {
      setGoals([
        ...goals,
        {
          id: Date.now().toString(),
          ...newGoal,
        },
      ])
      setNewGoal({ title: "", description: "", progress: 0, category: "academic" })
      setIsAddDialogOpen(false)
    }
  }

  const updateGoal = () => {
    if (editingGoal && editingGoal.title.trim()) {
      setGoals(goals.map((goal) => (goal.id === editingGoal.id ? editingGoal : goal)))
      setEditingGoal(null)
      setIsEditDialogOpen(false)
    }
  }

  const deleteGoal = (id: string) => {
    setGoals(goals.filter((goal) => goal.id !== id))
  }

  const getCategoryIcon = (category: Goal["category"]) => {
    switch (category) {
      case "academic":
        return <Award className="h-4 w-4 text-asu-maroon" />
      case "career":
        return <TrendingUp className="h-4 w-4 text-green-600" />
      case "personal":
        return <Target className="h-4 w-4 text-blue-600" />
      case "research":
        return <Target className="h-4 w-4 text-purple-600" />
      default:
        return <Target className="h-4 w-4" />
    }
  }

  const getCategoryColor = (category: Goal["category"]) => {
    switch (category) {
      case "academic":
        return "bg-asu-maroon text-white"
      case "career":
        return "bg-green-600 text-white"
      case "personal":
        return "bg-blue-600 text-white"
      case "research":
        return "bg-purple-600 text-white"
      default:
        return "bg-gray-600 text-white"
    }
  }

  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-asu-maroon flex items-center">
              <Target className="h-5 w-5 mr-2 text-asu-gold" />
              Semester Goals
            </CardTitle>
            <CardDescription>Track your progress for the semester</CardDescription>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-asu-maroon hover:bg-asu-maroon/90">
                <Plus className="h-4 w-4 mr-1" />
                Add Goal
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Semester Goal</DialogTitle>
                <DialogDescription>Create a new goal to track throughout the semester</DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <label htmlFor="title" className="text-sm font-medium">
                    Goal Title
                  </label>
                  <Input
                    id="title"
                    value={newGoal.title}
                    onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                    placeholder="e.g., Maintain 3.5+ GPA"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="description" className="text-sm font-medium">
                    Description
                  </label>
                  <Textarea
                    id="description"
                    value={newGoal.description}
                    onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                    placeholder="Describe your goal and action steps"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="category" className="text-sm font-medium">
                    Category
                  </label>
                  <select
                    id="category"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={newGoal.category}
                    onChange={(e) => setNewGoal({ ...newGoal, category: e.target.value as Goal["category"] })}
                  >
                    <option value="academic">Academic</option>
                    <option value="career">Career</option>
                    <option value="personal">Personal</option>
                    <option value="research">Research</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label htmlFor="deadline" className="text-sm font-medium">
                    Deadline (Optional)
                  </label>
                  <Input
                    id="deadline"
                    placeholder="e.g., End of semester, October 15"
                    onChange={(e) => setNewGoal({ ...newGoal, deadline: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="progress" className="text-sm font-medium">
                    Initial Progress: {newGoal.progress}%
                  </label>
                  <Input
                    id="progress"
                    type="range"
                    min="0"
                    max="100"
                    value={newGoal.progress}
                    onChange={(e) => setNewGoal({ ...newGoal, progress: Number.parseInt(e.target.value) })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={addGoal} className="bg-asu-maroon hover:bg-asu-maroon/90">
                  Add Goal
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {goals.map((goal) => (
            <div key={goal.id} className="space-y-2 p-4 rounded-lg border shadow-sm">
              <div className="flex justify-between items-start">
                <div className="flex items-start gap-2">
                  {getCategoryIcon(goal.category)}
                  <div>
                    <h3 className="font-medium">{goal.title}</h3>
                    <Badge className={`text-xs mt-1 ${getCategoryColor(goal.category)}`}>
                      {goal.category.charAt(0).toUpperCase() + goal.category.slice(1)}
                    </Badge>
                  </div>
                </div>
                <div className="flex space-x-1">
                  <Dialog
                    open={isEditDialogOpen && editingGoal?.id === goal.id}
                    onOpenChange={(open) => {
                      setIsEditDialogOpen(open)
                      if (!open) setEditingGoal(null)
                    }}
                  >
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="sm" onClick={() => setEditingGoal(goal)}>
                        <Edit2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Edit Semester Goal</DialogTitle>
                        <DialogDescription>Update your goal details and progress</DialogDescription>
                      </DialogHeader>
                      {editingGoal && (
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <label htmlFor="edit-title" className="text-sm font-medium">
                              Goal Title
                            </label>
                            <Input
                              id="edit-title"
                              value={editingGoal.title}
                              onChange={(e) => setEditingGoal({ ...editingGoal, title: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="edit-description" className="text-sm font-medium">
                              Description
                            </label>
                            <Textarea
                              id="edit-description"
                              value={editingGoal.description}
                              onChange={(e) => setEditingGoal({ ...editingGoal, description: e.target.value })}
                              rows={3}
                            />
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="edit-category" className="text-sm font-medium">
                              Category
                            </label>
                            <select
                              id="edit-category"
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                              value={editingGoal.category}
                              onChange={(e) =>
                                setEditingGoal({ ...editingGoal, category: e.target.value as Goal["category"] })
                              }
                            >
                              <option value="academic">Academic</option>
                              <option value="career">Career</option>
                              <option value="personal">Personal</option>
                              <option value="research">Research</option>
                            </select>
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="edit-deadline" className="text-sm font-medium">
                              Deadline (Optional)
                            </label>
                            <Input
                              id="edit-deadline"
                              value={editingGoal.deadline || ""}
                              onChange={(e) => setEditingGoal({ ...editingGoal, deadline: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <label htmlFor="edit-progress" className="text-sm font-medium">
                              Progress: {editingGoal.progress}%
                            </label>
                            <Input
                              id="edit-progress"
                              type="range"
                              min="0"
                              max="100"
                              value={editingGoal.progress}
                              onChange={(e) =>
                                setEditingGoal({ ...editingGoal, progress: Number.parseInt(e.target.value) })
                              }
                            />
                          </div>
                        </div>
                      )}
                      <DialogFooter>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setEditingGoal(null)
                            setIsEditDialogOpen(false)
                          }}
                        >
                          Cancel
                        </Button>
                        <Button onClick={updateGoal} className="bg-asu-maroon hover:bg-asu-maroon/90">
                          Save Changes
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                  <Button variant="ghost" size="sm" onClick={() => deleteGoal(goal.id)}>
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{goal.description}</p>
              {goal.deadline && (
                <p className="text-xs text-muted-foreground">
                  <span className="font-medium">Deadline:</span> {goal.deadline}
                </p>
              )}
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Progress</span>
                  <span>{goal.progress}%</span>
                </div>
                <Progress
                  value={goal.progress}
                  className="h-2"
                  indicatorClassName={goal.progress >= 100 ? "bg-green-600" : "bg-asu-maroon"}
                />
              </div>
            </div>
          ))}
          {goals.length === 0 && (
            <div className="col-span-3 text-center py-8">
              <p className="text-muted-foreground">No semester goals yet. Add some to track your progress!</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

