"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, Clock, CheckCircle2, AlertCircle } from "lucide-react"

type Task = {
  id: string
  text: string
  completed: boolean
  priority: "high" | "medium" | "low"
  dueTime?: string
}

export default function TodayTasks() {
  const [tasks, setTasks] = useState<Task[]>([
    { id: "1", text: "Complete CSE 355 homework", completed: false, priority: "high", dueTime: "11:59 PM" },
    { id: "2", text: "Study for MAT 343 quiz", completed: false, priority: "high", dueTime: "3:00 PM" },
    { id: "3", text: "Meet with project team at 3pm", completed: true, priority: "medium", dueTime: "3:00 PM" },
    { id: "4", text: "Email professor about research opportunity", completed: false, priority: "medium" },
    { id: "5", text: "Review lecture notes for CSE 340", completed: false, priority: "medium" },
    { id: "6", text: "Submit Canvas discussion post", completed: true, priority: "high", dueTime: "11:59 PM" },
    { id: "7", text: "Prepare presentation slides for ENG 302", completed: false, priority: "low" },
    { id: "8", text: "Register for fall semester classes", completed: false, priority: "high" },
  ])
  const [newTask, setNewTask] = useState("")
  const [newTaskPriority, setNewTaskPriority] = useState<Task["priority"]>("medium")

  const addTask = () => {
    if (newTask.trim()) {
      setTasks([
        ...tasks,
        {
          id: Date.now().toString(),
          text: newTask,
          completed: false,
          priority: newTaskPriority,
        },
      ])
      setNewTask("")
    }
  }

  const toggleTask = (id: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  const getPriorityColor = (priority: Task["priority"]) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const getPriorityIcon = (priority: Task["priority"]) => {
    switch (priority) {
      case "high":
        return <AlertCircle className="h-3 w-3 text-red-500" />
      case "medium":
        return <Clock className="h-3 w-3 text-yellow-500" />
      case "low":
        return <CheckCircle2 className="h-3 w-3 text-green-500" />
      default:
        return null
    }
  }

  // Filter tasks
  const completedTasks = tasks.filter((t) => t.completed)
  const pendingTasks = tasks.filter((t) => !t.completed)
  const highPriorityTasks = pendingTasks.filter((t) => t.priority === "high")
  const otherTasks = pendingTasks.filter((t) => t.priority !== "high")

  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-2 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-asu-maroon flex items-center text-lg">
              Today's To-Do List
              <Badge className="ml-2 bg-asu-gold text-asu-maroon">{pendingTasks.length} remaining</Badge>
            </CardTitle>
            <CardDescription>Tasks for {new Date().toLocaleDateString()}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Input
              placeholder="Add a new task..."
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && addTask()}
              className="w-48 h-8 border-asu-maroon/20 focus-visible:ring-asu-maroon text-sm"
            />
            <select
              className="h-8 rounded-l-md border border-r-0 border-input bg-background text-xs px-2"
              value={newTaskPriority}
              onChange={(e) => setNewTaskPriority(e.target.value as Task["priority"])}
            >
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
            <Button size="sm" className="h-8 rounded-l-none bg-asu-maroon hover:bg-asu-maroon/90" onClick={addTask}>
              <Plus className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-3">
        <div className="space-y-1 max-h-[250px] overflow-auto pr-2">
          {/* High Priority Tasks */}
          {highPriorityTasks.length > 0 && (
            <div className="mb-2">
              <div className="flex items-center gap-1 mb-1">
                <AlertCircle className="h-3 w-3 text-red-500" />
                <span className="text-xs font-medium text-red-500">High Priority</span>
              </div>
              {highPriorityTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between py-1.5 px-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800"
                >
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.completed}
                      onCheckedChange={() => toggleTask(task.id)}
                      className="border-asu-maroon data-[state=checked]:bg-asu-maroon data-[state=checked]:text-white h-4 w-4"
                    />
                    <div>
                      <label
                        htmlFor={`task-${task.id}`}
                        className={`text-sm ${task.completed ? "line-through text-muted-foreground" : "font-medium"}`}
                      >
                        {task.text}
                      </label>
                      {task.dueTime && (
                        <span className="text-xs text-muted-foreground flex items-center ml-1">
                          <Clock className="h-2.5 w-2.5 mr-0.5" />
                          {task.dueTime}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => deleteTask(task.id)} className="h-6 w-6 p-0">
                    <Trash2 className="h-3 w-3 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Other Tasks */}
          {otherTasks.length > 0 && (
            <div>
              <div className="flex items-center gap-1 mb-1">
                <Clock className="h-3 w-3 text-gray-500" />
                <span className="text-xs font-medium text-gray-500">Other Tasks</span>
              </div>
              {otherTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between py-1.5 px-2 rounded-md hover:bg-gray-50 dark:hover:bg-gray-800/50 border-b border-gray-100 dark:border-gray-800"
                >
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.completed}
                      onCheckedChange={() => toggleTask(task.id)}
                      className="border-asu-maroon data-[state=checked]:bg-asu-maroon data-[state=checked]:text-white h-4 w-4"
                    />
                    <div>
                      <label
                        htmlFor={`task-${task.id}`}
                        className={`text-sm ${task.completed ? "line-through text-muted-foreground" : ""}`}
                      >
                        {task.text}
                      </label>
                      <div className="flex items-center gap-1">
                        <Badge variant="outline" className={`text-xs py-0 h-4 ${getPriorityColor(task.priority)}`}>
                          {getPriorityIcon(task.priority)}
                          <span className="ml-0.5">{task.priority}</span>
                        </Badge>
                        {task.dueTime && (
                          <span className="text-xs text-muted-foreground flex items-center">
                            <Clock className="h-2.5 w-2.5 mr-0.5" />
                            {task.dueTime}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => deleteTask(task.id)} className="h-6 w-6 p-0">
                    <Trash2 className="h-3 w-3 text-muted-foreground" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Completed Tasks */}
          {completedTasks.length > 0 && (
            <div className="mt-3">
              <div className="flex items-center gap-1 mb-1">
                <CheckCircle2 className="h-3 w-3 text-green-500" />
                <span className="text-xs font-medium text-green-500">Completed ({completedTasks.length})</span>
              </div>
              {completedTasks.slice(0, 3).map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between py-1.5 px-2 rounded-md bg-gray-50/50 dark:bg-gray-800/20 border-b border-gray-100 dark:border-gray-800"
                >
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.completed}
                      onCheckedChange={() => toggleTask(task.id)}
                      className="border-green-500 data-[state=checked]:bg-green-500 data-[state=checked]:text-white h-4 w-4"
                    />
                    <label htmlFor={`task-${task.id}`} className="text-sm line-through text-muted-foreground">
                      {task.text}
                    </label>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => deleteTask(task.id)} className="h-6 w-6 p-0">
                    <Trash2 className="h-3 w-3 text-muted-foreground" />
                  </Button>
                </div>
              ))}
              {completedTasks.length > 3 && (
                <div className="text-center text-xs text-muted-foreground mt-1">
                  +{completedTasks.length - 3} more completed tasks
                </div>
              )}
            </div>
          )}

          {tasks.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-4">
              No tasks for today. Add some to get started!
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

