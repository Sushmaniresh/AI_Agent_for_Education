"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Trash2, CalendarDays } from "lucide-react"

type WeeklyTask = {
  id: string
  text: string
  completed: boolean
  day: string
  priority: "high" | "medium" | "low"
}

const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

export default function WeeklyTasks() {
  const [tasks, setTasks] = useState<WeeklyTask[]>([
    { id: "1", text: "Complete CSE project milestone", completed: false, day: "Monday", priority: "high" },
    { id: "2", text: "Study for midterm exam", completed: false, day: "Tuesday", priority: "high" },
    { id: "3", text: "Meet with advisor", completed: true, day: "Wednesday", priority: "medium" },
    { id: "4", text: "Submit research paper draft", completed: false, day: "Thursday", priority: "high" },
    { id: "5", text: "Group presentation preparation", completed: false, day: "Friday", priority: "medium" },
    { id: "6", text: "Review lecture recordings", completed: false, day: "Monday", priority: "medium" },
    { id: "7", text: "Complete online quiz", completed: true, day: "Tuesday", priority: "high" },
    { id: "8", text: "Attend career fair", completed: false, day: "Wednesday", priority: "medium" },
    { id: "9", text: "Work on portfolio website", completed: false, day: "Saturday", priority: "low" },
    { id: "10", text: "Read textbook chapters 7-9", completed: false, day: "Sunday", priority: "medium" },
  ])
  const [newTask, setNewTask] = useState("")
  const [selectedDay, setSelectedDay] = useState("Monday")
  const [newTaskPriority, setNewTaskPriority] = useState<WeeklyTask["priority"]>("medium")

  const addTask = () => {
    if (newTask.trim()) {
      setTasks([
        ...tasks,
        {
          id: Date.now().toString(),
          text: newTask,
          completed: false,
          day: selectedDay,
          priority: newTaskPriority,
        },
      ])
      setNewTask("")
    }
  }

  const toggleTask = (id: string) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, completed: !task.completed } : task)))
  }

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
  }

  const getPriorityColor = (priority: WeeklyTask["priority"]) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "low":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-asu-maroon flex items-center">
              <CalendarDays className="h-5 w-5 mr-2 text-asu-gold" />
              Weekly To-Do List
            </CardTitle>
            <CardDescription>Plan your tasks for the week</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="Monday">
          <TabsList className="grid grid-cols-7 mb-4 bg-white dark:bg-gray-800">
            {DAYS.map((day) => (
              <TabsTrigger
                key={day}
                value={day}
                onClick={() => setSelectedDay(day)}
                className="text-xs data-[state=active]:bg-asu-maroon data-[state=active]:text-white"
              >
                {day.substring(0, 3)}
              </TabsTrigger>
            ))}
          </TabsList>

          {DAYS.map((day) => (
            <TabsContent key={day} value={day} className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder={`Add task for ${day}...`}
                  value={newTask}
                  onChange={(e) => setNewTask(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && addTask()}
                  className="border-asu-maroon/20 focus-visible:ring-asu-maroon"
                />
                <div className="flex">
                  <select
                    className="px-2 py-0 h-10 rounded-l-md border border-r-0 border-input bg-background text-sm"
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value as WeeklyTask["priority"])}
                  >
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                  <Button size="sm" className="rounded-l-none bg-asu-maroon hover:bg-asu-maroon/90" onClick={addTask}>
                    <Plus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>
              </div>

              <div className="space-y-2 max-h-[250px] overflow-auto pr-2">
                {tasks
                  .filter((task) => task.day === day)
                  .map((task) => (
                    <div
                      key={task.id}
                      className={`flex items-center justify-between p-2 rounded-md ${
                        task.completed ? "bg-muted/50" : "bg-white dark:bg-gray-800"
                      } border shadow-sm`}
                    >
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`weekly-task-${task.id}`}
                          checked={task.completed}
                          onCheckedChange={() => toggleTask(task.id)}
                          className="border-asu-maroon data-[state=checked]:bg-asu-maroon data-[state=checked]:text-white"
                        />
                        <div>
                          <label
                            htmlFor={`weekly-task-${task.id}`}
                            className={`text-sm ${task.completed ? "line-through text-muted-foreground" : "font-medium"}`}
                          >
                            {task.text}
                          </label>
                          <div className="mt-1">
                            <Badge variant="outline" className={`text-xs ${getPriorityColor(task.priority)}`}>
                              {task.priority}
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => deleteTask(task.id)}>
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  ))}
                {tasks.filter((task) => task.day === day).length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No tasks for {day}. Add some to get started!
                  </p>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}

