"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Filter, BookOpen, Users, Calendar, Mail, ExternalLink } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type Professor = {
  id: string
  name: string
  department: string
  researchAreas: string[]
  availability: string
  email?: string
  website?: string
  imageUrl?: string
}

export default function CollabView() {
  const [searchQuery, setSearchQuery] = useState("")
  const [departmentFilter, setDepartmentFilter] = useState<string | undefined>(undefined)

  // Sample data - would come from your backend/API
  const professors: Professor[] = [
    {
      id: "1",
      name: "Dr. Sarah Johnson",
      department: "Computer Science",
      researchAreas: ["Artificial Intelligence", "Machine Learning", "Computer Vision"],
      availability: "Tuesdays and Thursdays, 2-4 PM",
      email: "sarah.johnson@asu.edu",
      website: "https://faculty.asu.edu/johnson",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "2",
      name: "Dr. Michael Chen",
      department: "Electrical Engineering",
      researchAreas: ["Robotics", "Control Systems", "Embedded Systems"],
      availability: "Mondays and Wednesdays, 1-3 PM",
      email: "michael.chen@asu.edu",
      website: "https://faculty.asu.edu/chen",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "3",
      name: "Dr. Emily Rodriguez",
      department: "Computer Science",
      researchAreas: ["Data Science", "Natural Language Processing", "Information Retrieval"],
      availability: "Fridays, 10 AM - 2 PM",
      email: "emily.rodriguez@asu.edu",
      website: "https://faculty.asu.edu/rodriguez",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "4",
      name: "Dr. James Wilson",
      department: "Mathematics",
      researchAreas: ["Computational Mathematics", "Algorithms", "Optimization"],
      availability: "Tuesdays and Thursdays, 10 AM - 12 PM",
      email: "james.wilson@asu.edu",
      website: "https://faculty.asu.edu/wilson",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "5",
      name: "Dr. Lisa Patel",
      department: "Electrical Engineering",
      researchAreas: ["Signal Processing", "Communications", "Machine Learning"],
      availability: "Mondays and Wednesdays, 3-5 PM",
      email: "lisa.patel@asu.edu",
      website: "https://faculty.asu.edu/patel",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "6",
      name: "Dr. Robert Thompson",
      department: "Computer Science",
      researchAreas: ["Cybersecurity", "Network Systems", "Blockchain"],
      availability: "Wednesdays, 1-5 PM",
      email: "robert.thompson@asu.edu",
      website: "https://faculty.asu.edu/thompson",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "7",
      name: "Dr. Maria Garcia",
      department: "Industrial Engineering",
      researchAreas: ["Operations Research", "Supply Chain", "Data Analytics"],
      availability: "Mondays and Fridays, 11 AM - 1 PM",
      email: "maria.garcia@asu.edu",
      website: "https://faculty.asu.edu/garcia",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
    {
      id: "8",
      name: "Dr. David Kim",
      department: "Computer Science",
      researchAreas: ["Human-Computer Interaction", "Virtual Reality", "User Experience"],
      availability: "Tuesdays, 9 AM - 3 PM",
      email: "david.kim@asu.edu",
      website: "https://faculty.asu.edu/kim",
      imageUrl: "/placeholder.svg?height=100&width=100",
    },
  ]

  const filteredProfessors = professors.filter((professor) => {
    const matchesSearch =
      searchQuery === "" ||
      professor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      professor.researchAreas.some((area) => area.toLowerCase().includes(searchQuery.toLowerCase()))

    const matchesDepartment = !departmentFilter || professor.department === departmentFilter

    return matchesSearch && matchesDepartment
  })

  // Get unique departments for filter
  const departments = Array.from(new Set(professors.map((p) => p.department)))

  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-asu-maroon flex items-center">
              <Users className="h-5 w-5 mr-2 text-asu-gold" />
              Find Professors
            </CardTitle>
            <CardDescription>Connect with professors based on your research interests</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="professors">
          <TabsList className="mb-4 bg-white dark:bg-gray-800">
            <TabsTrigger
              value="professors"
              className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white"
            >
              <Users className="h-4 w-4 mr-2" />
              Professors
            </TabsTrigger>
            <TabsTrigger value="research" className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white">
              <BookOpen className="h-4 w-4 mr-2" />
              Research Areas
            </TabsTrigger>
            <TabsTrigger
              value="office-hours"
              className="data-[state=active]:bg-asu-maroon data-[state=active]:text-white"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Office Hours
            </TabsTrigger>
          </TabsList>

          <TabsContent value="professors" className="space-y-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or research interest..."
                  className="pl-8 border-asu-maroon/20 focus-visible:ring-asu-maroon"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                <SelectTrigger className="w-[200px] border-asu-maroon/20">
                  <SelectValue placeholder="Filter by department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="icon"
                onClick={() => {
                  setSearchQuery("")
                  setDepartmentFilter(undefined)
                }}
                className="border-asu-maroon/20"
              >
                <Filter className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredProfessors.map((professor) => (
                <Card key={professor.id} className="border shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex gap-4">
                      <Avatar className="h-16 w-16 border-2 border-asu-maroon">
                        <AvatarImage src={professor.imageUrl} alt={professor.name} />
                        <AvatarFallback className="bg-asu-maroon text-white">
                          {professor.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-medium text-asu-maroon">{professor.name}</h3>
                        <p className="text-sm text-muted-foreground">{professor.department}</p>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {professor.researchAreas.map((area) => (
                            <Badge
                              key={area}
                              variant="outline"
                              className="text-xs bg-asu-gold/10 text-asu-maroon border-asu-gold"
                            >
                              {area}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs mt-2">
                          <span className="font-medium">Availability:</span> {professor.availability}
                        </p>
                      </div>
                    </div>
                    <div className="flex justify-between mt-4">
                      <div className="flex gap-2">
                        {professor.email && (
                          <Button size="sm" variant="outline" className="h-8 px-2 text-xs border-asu-maroon/20">
                            <Mail className="h-3 w-3 mr-1" />
                            Email
                          </Button>
                        )}
                        {professor.website && (
                          <Button size="sm" variant="outline" className="h-8 px-2 text-xs border-asu-maroon/20">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Website
                          </Button>
                        )}
                      </div>
                      <Button size="sm" className="bg-asu-maroon hover:bg-asu-maroon/90">
                        Contact
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {filteredProfessors.length === 0 && (
                <div className="col-span-2 text-center py-8">
                  <p className="text-muted-foreground">No professors match your search criteria.</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="research">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="bg-asu-maroon text-white p-4">
                  <CardTitle className="text-lg">Artificial Intelligence</CardTitle>
                  <CardDescription className="text-white/80">
                    Machine Learning, Neural Networks, Computer Vision
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <p className="text-sm mb-4">
                    Current research in AI focuses on developing advanced algorithms and models for solving complex
                    problems.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-asu-maroon">
                        <AvatarFallback className="bg-asu-maroon text-white">SJ</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">Dr. Sarah Johnson</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-asu-maroon">
                        <AvatarFallback className="bg-asu-maroon text-white">LP</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">Dr. Lisa Patel</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="bg-asu-maroon text-white p-4">
                  <CardTitle className="text-lg">Robotics & Control</CardTitle>
                  <CardDescription className="text-white/80">
                    Autonomous Systems, Embedded Systems, Sensors
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <p className="text-sm mb-4">
                    Research in robotics explores the development of intelligent machines that can interact with the
                    physical world.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-asu-maroon">
                        <AvatarFallback className="bg-asu-maroon text-white">MC</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">Dr. Michael Chen</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="bg-asu-maroon text-white p-4">
                  <CardTitle className="text-lg">Data Science</CardTitle>
                  <CardDescription className="text-white/80">
                    Big Data, Analytics, Natural Language Processing
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-4">
                  <p className="text-sm mb-4">
                    Data science research focuses on extracting knowledge and insights from structured and unstructured
                    data.
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-asu-maroon">
                        <AvatarFallback className="bg-asu-maroon text-white">ER</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">Dr. Emily Rodriguez</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Avatar className="h-8 w-8 border border-asu-maroon">
                        <AvatarFallback className="bg-asu-maroon text-white">MG</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">Dr. Maria Garcia</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="office-hours">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="border shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-asu-maroon">Monday</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Michael Chen</p>
                          <p className="text-sm text-muted-foreground">1:00 PM - 3:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: BYENG 210</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Lisa Patel</p>
                          <p className="text-sm text-muted-foreground">3:00 PM - 5:00 PM</p>
                        </div>
                        <Badge className="bg-yellow-500">By Appointment</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: GWC 352</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Maria Garcia</p>
                          <p className="text-sm text-muted-foreground">11:00 AM - 1:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: ISTB4 586</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-asu-maroon">Tuesday</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Sarah Johnson</p>
                          <p className="text-sm text-muted-foreground">2:00 PM - 4:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: BYENG 444</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. James Wilson</p>
                          <p className="text-sm text-muted-foreground">10:00 AM - 12:00 PM</p>
                        </div>
                        <Badge className="bg-yellow-500">By Appointment</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: PSA 728</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. David Kim</p>
                          <p className="text-sm text-muted-foreground">9:00 AM - 3:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: COOR 230</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-asu-maroon">Wednesday</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Michael Chen</p>
                          <p className="text-sm text-muted-foreground">1:00 PM - 3:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: BYENG 210</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Robert Thompson</p>
                          <p className="text-sm text-muted-foreground">1:00 PM - 5:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: BYAC 190</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Emily Rodriguez</p>
                          <p className="text-sm text-muted-foreground">3:00 PM - 5:00 PM</p>
                        </div>
                        <Badge className="bg-red-600">Booked</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: CAVC 375</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg text-asu-maroon">Thursday</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. Sarah Johnson</p>
                          <p className="text-sm text-muted-foreground">2:00 PM - 4:00 PM</p>
                        </div>
                        <Badge className="bg-yellow-500">By Appointment</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: BYENG 444</p>
                    </div>
                    <div className="p-3 rounded-md border">
                      <div className="flex justify-between">
                        <div>
                          <p className="font-medium">Dr. James Wilson</p>
                          <p className="text-sm text-muted-foreground">10:00 AM - 12:00 PM</p>
                        </div>
                        <Badge className="bg-green-600">Available</Badge>
                      </div>
                      <p className="text-xs mt-1">Location: PSA 728</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

