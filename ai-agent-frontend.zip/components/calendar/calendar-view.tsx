"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CalendarIcon, Filter, PlusCircle, ChevronLeft, ChevronRight } from "lucide-react"

type CalendarEvent = {
  id: string
  title: string
  start: Date
  end: Date
  type: "class" | "study" | "meeting" | "personal" | "deadline" | "assignment" | "exam" | "event"
  source: "myasu" | "canvas" | "manual" | "asu-events"
  location?: string
  description?: string
}

export default function CalendarView() {
  const [currentDate] = useState(new Date())
  const [filter, setFilter] = useState<string | undefined>(undefined)

  // Sample data - would come from your backend/API
  const events: CalendarEvent[] = [
    {
      id: "1",
      title: "CSE 355 Lecture",
      start: new Date(currentDate.setHours(9, 0, 0, 0)),
      end: new Date(currentDate.setHours(10, 15, 0, 0)),
      type: "class",
      source: "myasu",
      location: "CAVC 351",
      description: "Theory of Computation with Dr. Johnson",
    },
    {
      id: "2",
      title: "MAT 343 Lecture",
      start: new Date(currentDate.setHours(11, 0, 0, 0)),
      end: new Date(currentDate.setHours(12, 15, 0, 0)),
      type: "class",
      source: "myasu",
      location: "PSH 356",
      description: "Applied Linear Algebra with Dr. Chen",
    },
    {
      id: "3",
      title: "Project Deadline",
      start: new Date(currentDate.setHours(23, 59, 0, 0)),
      end: new Date(currentDate.setHours(23, 59, 0, 0)),
      type: "deadline",
      source: "canvas",
      description: "Final submission for CSE 340 project",
    },
    {
      id: "4",
      title: "Study Group",
      start: new Date(currentDate.setHours(14, 0, 0, 0)),
      end: new Date(currentDate.setHours(16, 0, 0, 0)),
      type: "study",
      source: "manual",
      location: "Hayden Library, Room 202",
      description: "Study group for upcoming midterm",
    },
    {
      id: "5",
      title: "Hackathon Registration",
      start: new Date(currentDate.setHours(18, 0, 0, 0)),
      end: new Date(currentDate.setHours(19, 0, 0, 0)),
      type: "event",
      source: "asu-events",
      location: "Memorial Union",
      description: "Register for the ASU Innovation Hackathon",
    },
    {
      id: "6",
      title: "Research Meeting",
      start: new Date(currentDate.setHours(15, 30, 0, 0)),
      end: new Date(currentDate.setHours(16, 30, 0, 0)),
      type: "meeting",
      source: "manual",
      location: "BYENG 210",
      description: "Weekly meeting with research advisor",
    },
    {
      id: "7",
      title: "Canvas Quiz Due",
      start: new Date(currentDate.setHours(23, 59, 0, 0)),
      end: new Date(currentDate.setHours(23, 59, 0, 0)),
      type: "assignment",
      source: "canvas",
      description: "Online quiz for CSE 230",
    },
    {
      id: "8",
      title: "Career Workshop",
      start: new Date(currentDate.setHours(13, 0, 0, 0)),
      end: new Date(currentDate.setHours(14, 30, 0, 0)),
      type: "event",
      source: "asu-events",
      location: "Student Pavilion",
      description: "Resume building and interview skills workshop",
    },
  ]

  const getTypeColor = (type: CalendarEvent["type"]) => {
    switch (type) {
      case "class":
        return "bg-asu-maroon text-white"
      case "study":
        return "bg-green-600 text-white"
      case "meeting":
        return "bg-purple-600 text-white"
      case "personal":
        return "bg-yellow-500 text-white"
      case "deadline":
        return "bg-red-600 text-white"
      case "assignment":
        return "bg-indigo-600 text-white"
      case "exam":
        return "bg-pink-600 text-white"
      case "event":
        return "bg-orange-500 text-white"
      default:
        return "bg-gray-600 text-white"
    }
  }

  const getSourceBadge = (source: CalendarEvent["source"]) => {
    switch (source) {
      case "myasu":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "canvas":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "manual":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
      case "asu-events":
        return "bg-asu-gold text-asu-maroon"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  const filteredEvents = filter ? events.filter((event) => event.source === filter || event.type === filter) : events

  // Generate time slots for the day view
  const timeSlots = Array.from({ length: 14 }, (_, i) => i + 8) // 8 AM to 9 PM

  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle className="text-asu-maroon flex items-center">
              <CalendarIcon className="h-5 w-5 mr-2 text-asu-gold" />
              Calendar
            </CardTitle>
            <CardDescription>
              View your schedule with integrated events from MyASU, Canvas, and ASU events
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[180px] border-asu-maroon/20">
                <SelectValue placeholder="Filter events" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Events</SelectItem>
                <SelectItem value="myasu">MyASU</SelectItem>
                <SelectItem value="canvas">Canvas</SelectItem>
                <SelectItem value="asu-events">ASU Events</SelectItem>
                <SelectItem value="manual">Manual</SelectItem>
                <SelectItem value="class">Classes</SelectItem>
                <SelectItem value="deadline">Deadlines</SelectItem>
                <SelectItem value="study">Study</SelectItem>
                <SelectItem value="event">Events</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={() => setFilter(undefined)} className="border-asu-maroon/20">
              <Filter className="h-4 w-4" />
            </Button>
            <Button size="sm" className="bg-asu-maroon hover:bg-asu-maroon/90">
              <PlusCircle className="h-4 w-4 mr-1" />
              Add Event
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Button variant="outline" size="icon" className="mr-2 border-asu-maroon/20">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <h2 className="text-xl font-semibold flex items-center">
              <CalendarIcon className="mr-2 h-5 w-5 text-asu-gold" />
              {currentDate.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
            </h2>
            <Button variant="outline" size="icon" className="ml-2 border-asu-maroon/20">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex gap-2">
            <Badge className="bg-asu-maroon">Classes</Badge>
            <Badge className="bg-green-600">Study</Badge>
            <Badge className="bg-red-600">Deadlines</Badge>
          </div>
        </div>

        <div className="relative min-h-[600px] border rounded-md">
          {/* Time indicators */}
          <div className="absolute left-0 top-0 bottom-0 w-16 border-r bg-muted/50">
            {timeSlots.map((hour) => (
              <div key={hour} className="h-20 border-b flex items-start justify-center pt-1">
                <span className="text-xs text-muted-foreground">
                  {hour % 12 === 0 ? 12 : hour % 12} {hour < 12 ? "AM" : "PM"}
                </span>
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="ml-16 relative">
            {timeSlots.map((hour) => (
              <div key={hour} className="h-20 border-b"></div>
            ))}

            {/* Events */}
            {filteredEvents.map((event) => {
              const startHour = event.start.getHours()
              const startMinute = event.start.getMinutes()
              const endHour = event.end.getHours()
              const endMinute = event.end.getMinutes()

              const startPosition = (startHour - 8) * 80 + (startMinute / 60) * 80
              const duration = (((endHour - startHour) * 60 + (endMinute - startMinute)) / 60) * 80

              return (
                <div
                  key={event.id}
                  className={`absolute left-2 right-2 rounded-md p-2 ${getTypeColor(event.type)} border shadow-md`}
                  style={{
                    top: `${startPosition}px`,
                    height: `${duration}px`,
                    overflow: "hidden",
                  }}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-sm">{event.title}</p>
                      <p className="text-xs">
                        {event.start.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })} -
                        {event.end.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                      {event.location && <p className="text-xs mt-1 opacity-90">{event.location}</p>}
                    </div>
                    <Badge variant="outline" className={`text-xs ${getSourceBadge(event.source)}`}>
                      {event.source}
                    </Badge>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

