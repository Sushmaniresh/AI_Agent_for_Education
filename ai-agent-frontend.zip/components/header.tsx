"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { MoonIcon, SunIcon, Menu, Calendar, BookOpen, ListTodo, GraduationCap } from "lucide-react"
import { useTheme } from "next-themes"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Header() {
  const { setTheme, theme } = useTheme()
  const [isOpen, setIsOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-asu-maroon text-white">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center space-x-2">
            <GraduationCap className="h-6 w-6 text-asu-gold" />
            <span className="font-bold text-xl text-white">ASU Student Planner</span>
          </Link>
        </div>

        <nav className="hidden md:flex gap-6">
          <Link href="/" className="text-sm font-medium transition-colors hover:text-asu-gold flex items-center">
            <ListTodo className="mr-1 h-4 w-4" />
            Dashboard
          </Link>
          <Link
            href="#calendar"
            className="text-sm font-medium transition-colors hover:text-asu-gold flex items-center"
          >
            <Calendar className="mr-1 h-4 w-4" />
            Calendar
          </Link>
          <Link href="#collab" className="text-sm font-medium transition-colors hover:text-asu-gold flex items-center">
            <BookOpen className="mr-1 h-4 w-4" />
            Find Professors
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Toggle theme"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="text-white hover:text-asu-gold hover:bg-asu-maroon/80"
          >
            <SunIcon className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <MoonIcon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>

          <Avatar className="h-8 w-8 border-2 border-asu-gold">
            <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Student" />
            <AvatarFallback className="bg-asu-gold text-asu-maroon">AS</AvatarFallback>
          </Avatar>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="text-white hover:text-asu-gold hover:bg-asu-maroon/80">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col gap-4 mt-8">
                <Link
                  href="/"
                  className="text-sm font-medium transition-colors hover:text-asu-maroon flex items-center"
                  onClick={() => setIsOpen(false)}
                >
                  <ListTodo className="mr-2 h-4 w-4" />
                  Dashboard
                </Link>
                <Link
                  href="#calendar"
                  className="text-sm font-medium transition-colors hover:text-asu-maroon flex items-center"
                  onClick={() => setIsOpen(false)}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  Calendar
                </Link>
                <Link
                  href="#collab"
                  className="text-sm font-medium transition-colors hover:text-asu-maroon flex items-center"
                  onClick={() => setIsOpen(false)}
                >
                  <BookOpen className="mr-2 h-4 w-4" />
                  Find Professors
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}

