"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, BookOpen, BarChart, Brain, Bot, ArrowRight, Database, Cloud } from "lucide-react"

export default function AIAgentsDiagram() {
  return (
    <Card className="border-t-4 border-t-asu-maroon shadow-md">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-maroon/10 to-white dark:from-asu-maroon/20 dark:to-transparent">
        <CardTitle className="text-asu-maroon flex items-center">
          <Bot className="h-5 w-5 mr-2 text-asu-gold" />
          AI Agents System
        </CardTitle>
        <CardDescription>How our AI agents work together to power your Sun Devil Assistant</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex flex-col items-center">
          {/* User Input */}
          <div className="bg-asu-maroon text-white p-4 rounded-lg w-full max-w-md text-center mb-4">
            <p className="font-medium">User Query</p>
            <p className="text-sm opacity-80">
              "What's my schedule today and do I have time to meet with Dr. Johnson?"
            </p>
          </div>

          <ArrowRight className="h-8 w-8 text-asu-gold my-2" />

          {/* Central Assistant */}
          <div className="bg-asu-gold text-asu-maroon p-4 rounded-lg w-full max-w-md text-center mb-4">
            <div className="flex justify-center mb-2">
              <Bot className="h-6 w-6" />
            </div>
            <p className="font-medium">Sun Devil Assistant</p>
            <p className="text-sm">Query Analysis & Agent Coordination</p>
          </div>

          <ArrowRight className="h-8 w-8 text-asu-gold my-2 rotate-90" />

          {/* AWS Cloud */}
          <div className="border border-gray-300 rounded-lg p-4 w-full max-w-xl mb-4">
            <div className="flex justify-center mb-2">
              <Cloud className="h-6 w-6 text-asu-maroon" />
            </div>
            <p className="font-medium text-center mb-2">AWS Cloud Processing</p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4">
              {/* Agent 1 */}
              <div className="bg-blue-100 p-3 rounded-lg flex flex-col items-center text-center">
                <Calendar className="h-8 w-8 text-blue-600 mb-2" />
                <p className="font-medium text-sm">Schedule Agent</p>
                <p className="text-xs text-gray-600 mt-1">Analyzes calendar & optimizes time</p>
              </div>

              {/* Agent 2 */}
              <div className="bg-purple-100 p-3 rounded-lg flex flex-col items-center text-center">
                <BookOpen className="h-8 w-8 text-purple-600 mb-2" />
                <p className="font-medium text-sm">Professor Finder</p>
                <p className="text-xs text-gray-600 mt-1">Matches research interests & availability</p>
              </div>

              {/* Agent 3 */}
              <div className="bg-green-100 p-3 rounded-lg flex flex-col items-center text-center">
                <BarChart className="h-8 w-8 text-green-600 mb-2" />
                <p className="font-medium text-sm">Activity Tracker</p>
                <p className="text-xs text-gray-600 mt-1">Monitors progress & productivity</p>
              </div>

              {/* Agent 4 */}
              <div className="bg-yellow-100 p-3 rounded-lg flex flex-col items-center text-center">
                <Brain className="h-8 w-8 text-yellow-600 mb-2" />
                <p className="font-medium text-sm">Wellness Advisor</p>
                <p className="text-xs text-gray-600 mt-1">Analyzes mood & suggests balance</p>
              </div>
            </div>

            <div className="mt-4 border-t border-gray-200 pt-4">
              <div className="flex justify-center items-center gap-4">
                <div className="flex items-center">
                  <Database className="h-5 w-5 text-asu-maroon mr-1" />
                  <span className="text-xs">DynamoDB</span>
                </div>
                <div className="flex items-center">
                  <Database className="h-5 w-5 text-asu-maroon mr-1" />
                  <span className="text-xs">OpenSearch</span>
                </div>
                <div className="flex items-center">
                  <Database className="h-5 w-5 text-asu-maroon mr-1" />
                  <span className="text-xs">S3</span>
                </div>
              </div>
            </div>
          </div>

          <ArrowRight className="h-8 w-8 text-asu-gold my-2 rotate-90" />

          {/* Response */}
          <div className="bg-asu-maroon text-white p-4 rounded-lg w-full max-w-md">
            <p className="font-medium mb-2">Integrated Response:</p>
            <p className="text-sm">
              "You have CSE 355 at 9 AM and MAT 343 at 11 AM today. Dr. Johnson has office hours from 2-4 PM, which fits
              in your schedule before your 4:30 PM study group. Based on your current stress levels and assignment
              progress, I recommend taking this opportunity to discuss your research interests with her."
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

