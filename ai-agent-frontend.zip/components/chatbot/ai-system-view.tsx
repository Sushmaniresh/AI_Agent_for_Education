"use client"

import AIAgentsDiagram from "@/components/chatbot/ai-agents-diagram"
import AWSArchitecture from "@/components/chatbot/aws-architecture"
import ActivityTracker from "@/components/dashboard/activity-tracker"

export default function AISystemView() {
  return (
    <div className="space-y-4">
      <AIAgentsDiagram />
      <AWSArchitecture />
      <ActivityTracker />
    </div>
  )
}

