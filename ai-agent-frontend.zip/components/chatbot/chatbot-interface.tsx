"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar } from "@/components/ui/avatar"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, X, Minimize2, Bot, Calendar, BookOpen, Brain, BarChart } from "lucide-react"
import { Badge } from "@/components/ui/badge"

type Message = {
  id: string
  content: string
  role: "user" | "assistant"
  timestamp: Date
  agent?: "scheduler" | "professor" | "activity" | "sentiment" | null
}

export default function ChatbotInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content:
        "Hi there! I'm your ASU Sun Devil Assistant. Ask me about your schedule, professors, activities, or how you're doing. How can I help you today?",
      role: "assistant",
      timestamp: new Date(),
      agent: null,
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isMinimized, setIsMinimized] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const getAgentIcon = (agent: Message["agent"]) => {
    switch (agent) {
      case "scheduler":
        return <Calendar className="h-3 w-3 text-asu-gold" />
      case "professor":
        return <BookOpen className="h-3 w-3 text-asu-gold" />
      case "activity":
        return <BarChart className="h-3 w-3 text-asu-gold" />
      case "sentiment":
        return <Brain className="h-3 w-3 text-asu-gold" />
      default:
        return <Bot className="h-3 w-3 text-asu-gold" />
    }
  }

  const getAgentName = (agent: Message["agent"]) => {
    switch (agent) {
      case "scheduler":
        return "Schedule Agent"
      case "professor":
        return "Professor Finder"
      case "activity":
        return "Activity Tracker"
      case "sentiment":
        return "Wellness Advisor"
      default:
        return "Sun Devil Assistant"
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simulate API call to your AWS backend
    try {
      // This would connect to your AWS API Gateway in production
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Determine which agent should respond based on the query
      let agent: Message["agent"] = null
      let responseContent = ""

      if (
        input.toLowerCase().includes("schedule") ||
        input.toLowerCase().includes("agenda") ||
        input.toLowerCase().includes("today") ||
        input.toLowerCase().includes("class")
      ) {
        agent = "scheduler"
        responseContent = getScheduleResponse(input)
      } else if (
        input.toLowerCase().includes("professor") ||
        input.toLowerCase().includes("research") ||
        input.toLowerCase().includes("advisor")
      ) {
        agent = "professor"
        responseContent = getProfessorResponse(input)
      } else if (
        input.toLowerCase().includes("activity") ||
        input.toLowerCase().includes("github") ||
        input.toLowerCase().includes("leetcode") ||
        input.toLowerCase().includes("progress")
      ) {
        agent = "activity"
        responseContent = getActivityResponse(input)
      } else if (
        input.toLowerCase().includes("feel") ||
        input.toLowerCase().includes("stress") ||
        input.toLowerCase().includes("mood") ||
        input.toLowerCase().includes("mental")
      ) {
        agent = "sentiment"
        responseContent = getSentimentResponse(input)
      } else {
        // General response
        responseContent =
          "I can help you with your schedule, finding professors, tracking activities, or checking on your wellbeing. Could you specify what you need help with?"
      }

      // Simulate response
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: responseContent,
        role: "assistant",
        timestamp: new Date(),
        agent: agent,
      }

      setMessages((prev) => [...prev, botResponse])
    } catch (error) {
      console.error("Error fetching response:", error)

      // Add error message
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Sorry, I encountered an error processing your request. Please try again.",
        role: "assistant",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  // Sample responses from different agents
  const getScheduleResponse = (query: string) => {
    if (query.toLowerCase().includes("today")) {
      return "Today's agenda includes:\n\n• 9:00 AM - CSE 355 Lecture (CAVC 351)\n• 11:00 AM - MAT 343 Lecture (PSH 356)\n• 2:00 PM - Study Group (Hayden Library)\n• 4:00 PM - Project Meeting\n\nYou also have a Canvas assignment due at 11:59 PM tonight."
    } else if (query.toLowerCase().includes("tomorrow")) {
      return "Tomorrow you have:\n\n• 10:00 AM - ENG 302 Class\n• 1:00 PM - Advisor Meeting\n• 3:00 PM - Career Workshop at Student Pavilion\n\nI've optimized your schedule to include 2 hours of study time for your upcoming midterm."
    } else if (query.toLowerCase().includes("week")) {
      return "This week's highlights:\n\n• Wednesday: Research presentation\n• Thursday: CSE 340 midterm exam\n• Friday: Project deadline\n\nBased on your workload analysis, I recommend focusing on your CSE 340 studies on Tuesday."
    } else {
      return "I can show you your schedule for today, tomorrow, or this week. I can also help you optimize your study time based on upcoming deadlines. What would you like to know?"
    }
  }

  const getProfessorResponse = (query: string) => {
    if (query.toLowerCase().includes("research") || query.toLowerCase().includes("interest")) {
      return "Based on your interest in AI and machine learning, I recommend connecting with:\n\n• Dr. Sarah Johnson (Computer Science)\n• Dr. Lisa Patel (Electrical Engineering)\n\nBoth professors have office hours this week and are currently accepting research assistants. Would you like me to draft an introduction email?"
    } else if (query.toLowerCase().includes("office") || query.toLowerCase().includes("hours")) {
      return "Professors with office hours today:\n\n• Dr. Michael Chen: 1:00 PM - 3:00 PM (BYENG 210)\n• Dr. Lisa Patel: 3:00 PM - 5:00 PM (GWC 352)\n• Dr. Maria Garcia: 11:00 AM - 1:00 PM (ISTB4 586)\n\nBased on your schedule, you have time to visit Dr. Chen between your classes."
    } else {
      return "I can help you find professors based on research interests, check office hours, or suggest potential advisors for your academic goals. What specific information are you looking for?"
    }
  }

  const getActivityResponse = (query: string) => {
    if (query.toLowerCase().includes("github") || query.toLowerCase().includes("coding")) {
      return "GitHub Activity Analysis:\n\n• This week: 12 commits (↑20% from last week)\n• Current streak: 5 days\n• Most active project: ASU-ML-Project\n\nYour consistency has improved! Keep up the good work on your daily commits."
    } else if (query.toLowerCase().includes("leetcode")) {
      return "LeetCode Progress:\n\n• Problems solved: 87/150 target\n• Weekly goal: 5/5 completed ✓\n• Current focus: Dynamic Programming\n\nYou're making excellent progress toward your interview preparation goals!"
    } else if (query.toLowerCase().includes("progress") || query.toLowerCase().includes("productivity")) {
      return "Productivity Analysis:\n\n• Study time: 18 hours this week (↑2h from average)\n• Assignment completion: 5/5 on time\n• Focus sessions: 12 (avg. 52 minutes)\n\nYou're in the top 15% of productive students in your cohort!"
    } else {
      return "I track your coding activities on GitHub and LeetCode, monitor your study productivity, and analyze your progress toward goals. What specific activity would you like insights on?"
    }
  }

  const getSentimentResponse = (query: string) => {
    if (query.toLowerCase().includes("stress") || query.toLowerCase().includes("overwhelm")) {
      return "I've noticed your stress indicators have increased this week, likely due to your upcoming midterms. Consider:\n\n• Taking a 30-minute break for every 2 hours of study\n• Using the mindfulness resources at ASU Counseling Services\n• Breaking your project into smaller milestones\n\nWould you like me to schedule some breaks in your calendar?"
    } else if (query.toLowerCase().includes("mood") || query.toLowerCase().includes("feel")) {
      return "Based on our recent interactions and your activity patterns:\n\n• Your mood has been mostly positive this week\n• Sleep patterns appear consistent (avg. 7.2 hours)\n• Productivity is high, but watch for signs of burnout\n\nRemember to celebrate your accomplishments - you've completed all assignments on time this week!"
    } else {
      return "I can help monitor your stress levels, track mood patterns, and provide mental wellness suggestions based on your activity and communication patterns. How are you feeling today?"
    }
  }

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 transition-all duration-300 ease-in-out ${isMinimized ? "w-auto" : "w-[400px]"}`}
    >
      {isMinimized ? (
        <Button
          onClick={() => setIsMinimized(false)}
          className="rounded-full h-14 w-14 shadow-lg bg-asu-maroon hover:bg-asu-maroon/90"
        >
          <Bot className="h-6 w-6" />
        </Button>
      ) : (
        <Card className="shadow-xl border-asu-maroon">
          <CardHeader className="py-3 bg-asu-maroon text-white">
            <div className="flex justify-between items-center">
              <CardTitle className="text-base flex items-center">
                <Bot className="h-5 w-5 mr-2 text-asu-gold" />
                Sun Devil Assistant
              </CardTitle>
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-white hover:bg-asu-maroon/80"
                  onClick={() => setIsMinimized(true)}
                >
                  <Minimize2 className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-7 w-7 text-white hover:bg-asu-maroon/80"
                  onClick={() => setIsMinimized(true)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-[350px] p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`flex items-start gap-3 max-w-[85%]`}>
                      {message.role === "assistant" && (
                        <Avatar className="h-8 w-8 bg-asu-maroon">
                          <div className="text-xs font-medium text-white">AI</div>
                        </Avatar>
                      )}
                      <div
                        className={`rounded-lg px-4 py-2 ${
                          message.role === "user" ? "bg-asu-maroon text-white" : "bg-muted"
                        }`}
                      >
                        {message.agent && message.role === "assistant" && (
                          <div className="flex items-center mb-1">
                            <Badge
                              variant="outline"
                              className="text-xs px-1 py-0 h-4 bg-asu-gold/10 text-asu-maroon border-asu-gold flex items-center gap-1"
                            >
                              {getAgentIcon(message.agent)}
                              {getAgentName(message.agent)}
                            </Badge>
                          </div>
                        )}
                        <p className="text-sm whitespace-pre-line">{message.content}</p>
                        <p className="text-xs opacity-50 mt-1">
                          {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                      {message.role === "user" && (
                        <Avatar className="h-8 w-8 bg-asu-gold">
                          <div className="text-xs font-medium text-asu-maroon">You</div>
                        </Avatar>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="p-3 border-t">
            <form onSubmit={handleSubmit} className="flex w-full gap-2">
              <Input
                placeholder="Ask about your schedule, professors, activities..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={isLoading}
                className="flex-1 border-asu-maroon/20 focus-visible:ring-asu-maroon"
              />
              <Button type="submit" size="icon" disabled={isLoading} className="bg-asu-maroon hover:bg-asu-maroon/90">
                <Send className="h-4 w-4" />
                <span className="sr-only">Send message</span>
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}
    </div>
  )
}

