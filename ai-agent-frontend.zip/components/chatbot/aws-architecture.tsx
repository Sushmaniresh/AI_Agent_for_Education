"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Cloud } from "lucide-react"

export default function AWSArchitecture() {
  return (
    <Card className="border-t-4 border-t-asu-gold shadow-md mt-4">
      <CardHeader className="pb-3 bg-gradient-to-r from-asu-gold/10 to-white dark:from-asu-gold/20 dark:to-transparent">
        <CardTitle className="text-asu-maroon flex items-center">
          <Cloud className="h-5 w-5 mr-2 text-asu-gold" />
          AWS Cloud Architecture
        </CardTitle>
        <CardDescription>How the ASU Student Planner connects to AWS services</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="overflow-x-auto">
          <div className="min-w-[800px] relative">
            {/* Main AWS Architecture Diagram */}
            <div className="border-2 border-gray-400 rounded-lg p-6 bg-gray-50 dark:bg-gray-900">
              {/* AWS Cloud Header */}
              <div className="absolute top-4 left-4 flex items-center">
                <img
                  src="https://d1.awsstatic.com/logos/aws-logo-lockups/poweredbyaws/PB_AWS_logo_RGB_stacked_REV_SQ.91cd4af40773cbfbd15577a3c2b8a346fe3e8fa2.png"
                  alt="AWS Cloud"
                  width={40}
                  height={40}
                  className="mr-2"
                />
                <span className="font-medium text-gray-800 dark:text-gray-200">AWS Cloud</span>
              </div>

              {/* Customer Account Section */}
              <div className="border-2 border-blue-300 bg-blue-50 dark:bg-blue-950/30 rounded-lg p-4 mt-12 relative">
                <div className="absolute -top-3 left-4 bg-white dark:bg-gray-900 px-2 rounded-md">
                  <div className="flex items-center">
                    <img
                      src="https://d1.awsstatic.com/logos/aws-logo-lockups/poweredbyaws/PB_AWS_logo_RGB_stacked_REV_SQ.91cd4af40773cbfbd15577a3c2b8a346fe3e8fa2.png"
                      alt="AWS Account"
                      width={24}
                      height={24}
                      className="mr-2"
                    />
                    <span className="font-medium text-gray-800 dark:text-gray-200">Customer AWS Account</span>
                  </div>
                </div>

                <div className="grid grid-cols-12 gap-4">
                  {/* Client Side */}
                  <div className="col-span-2 flex flex-col items-center justify-start gap-4 border-r border-gray-300 dark:border-gray-700 pr-4">
                    <div className="text-center">
                      <div className="mb-2 text-xs font-medium text-gray-700 dark:text-gray-300">Client</div>
                      <div className="flex flex-col items-center gap-2">
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://static.vecteezy.com/system/resources/previews/011/994/022/original/computer-icon-sign-symbol-design-free-png.png"
                            alt="Web App"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Web App</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn-icons-png.flaticon.com/512/545/545245.png"
                            alt="Mobile App"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Mobile App</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn-icons-png.flaticon.com/512/1041/1041916.png"
                            alt="Chat App"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Chat App</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Frontend Layer */}
                  <div className="col-span-2 flex flex-col items-center justify-start gap-4">
                    <div className="text-center">
                      <div className="mb-2 text-xs font-medium text-gray-700 dark:text-gray-300">Frontend</div>
                      <div className="flex flex-col items-center gap-2">
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://d2908q01vomqb2.cloudfront.net/cb4e5208b4cd87268b208e49452ed6e89a68e0b8/2018/06/13/cloudfront-icon.png"
                            alt="CloudFront"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">CloudFront</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img src="https://cdn.worldvectorlogo.com/logos/aws-s3.svg" alt="S3" width={32} height={32} />
                          <span className="text-xs mt-1">S3 Website</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Authentication Layer */}
                  <div className="col-span-2 flex flex-col items-center justify-start gap-4">
                    <div className="text-center">
                      <div className="mb-2 text-xs font-medium text-gray-700 dark:text-gray-300">Authentication</div>
                      <div className="flex flex-col items-center gap-2">
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn.worldvectorlogo.com/logos/aws-cognito.svg"
                            alt="Cognito"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Cognito</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn.worldvectorlogo.com/logos/aws-iam.svg"
                            alt="IAM"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">IAM</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* API Layer */}
                  <div className="col-span-3 flex flex-col items-center justify-start gap-4">
                    <div className="text-center">
                      <div className="mb-2 text-xs font-medium text-gray-700 dark:text-gray-300">API Layer</div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn.worldvectorlogo.com/logos/aws-api-gateway.svg"
                            alt="API Gateway"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">API Gateway</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn.worldvectorlogo.com/logos/aws-lambda.svg"
                            alt="Lambda"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Lambda</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center relative">
                          <img
                            src="https://cdn.worldvectorlogo.com/logos/aws-step-functions.svg"
                            alt="Step Functions"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Step Functions</span>
                          <span className="absolute -bottom-2 text-[8px] bg-blue-100 dark:bg-blue-900 px-1 rounded text-blue-800 dark:text-blue-200">
                            Workflow Orchestration
                          </span>
                        </div>
                        <div className="p-2 border rounded-lg bg-white dark:bg-gray-800 shadow-md flex flex-col items-center relative">
                          <img
                            src="https://cdn.worldvectorlogo.com/logos/aws-eventbridge.svg"
                            alt="EventBridge"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">EventBridge</span>
                          <span className="absolute -bottom-2 text-[8px] bg-purple-100 dark:bg-purple-900 px-1 rounded text-purple-800 dark:text-purple-200">
                            Event Processing
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* AI Agents Layer */}
                  <div className="col-span-3 flex flex-col items-center justify-start gap-4">
                    <div className="text-center">
                      <div className="mb-2 text-xs font-medium text-gray-700 dark:text-gray-300">AI Agents</div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 border rounded-lg bg-asu-maroon/20 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn-icons-png.flaticon.com/512/2693/2693507.png"
                            alt="Scheduler"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Scheduler</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-asu-maroon/20 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn-icons-png.flaticon.com/512/3588/3588614.png"
                            alt="Professor Finder"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Professor Finder</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-asu-maroon/20 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn-icons-png.flaticon.com/512/1584/1584892.png"
                            alt="Activity Tracker"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Activity Tracker</span>
                        </div>
                        <div className="p-2 border rounded-lg bg-asu-maroon/20 shadow-md flex flex-col items-center">
                          <img
                            src="https://cdn-icons-png.flaticon.com/512/2491/2491921.png"
                            alt="Wellness Advisor"
                            width={32}
                            height={32}
                          />
                          <span className="text-xs mt-1">Wellness Advisor</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Database Layer */}
                <div className="mt-8 bg-gray-100 dark:bg-gray-800 p-4 rounded-lg shadow-inner">
                  <div className="text-center text-xs font-medium text-gray-700 dark:text-gray-300 mb-4">
                    Database Layer
                  </div>
                  <div className="flex justify-center gap-8">
                    <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                      <img
                        src="https://cdn.worldvectorlogo.com/logos/aws-dynamodb.svg"
                        alt="DynamoDB"
                        width={40}
                        height={40}
                      />
                      <span className="text-xs mt-1">DynamoDB</span>
                      <span className="text-[10px] text-gray-500 dark:text-gray-400">Primary Data Store</span>
                    </div>
                    <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                      <img
                        src="https://cdn.worldvectorlogo.com/logos/aws-opensearch-service.svg"
                        alt="OpenSearch"
                        width={40}
                        height={40}
                      />
                      <span className="text-xs mt-1">OpenSearch</span>
                      <span className="text-[10px] text-gray-500 dark:text-gray-400">Search & Analytics</span>
                    </div>
                    <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                      <img src="https://cdn.worldvectorlogo.com/logos/aws-s3.svg" alt="S3" width={40} height={40} />
                      <span className="text-xs mt-1">S3 Storage</span>
                      <span className="text-[10px] text-gray-500 dark:text-gray-400">Documents, Logs</span>
                    </div>
                    <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                      <img
                        src="https://cdn.worldvectorlogo.com/logos/aws-cloudwatch.svg"
                        alt="CloudWatch"
                        width={40}
                        height={40}
                      />
                      <span className="text-xs mt-1">CloudWatch</span>
                      <span className="text-[10px] text-gray-500 dark:text-gray-400">Monitoring</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* AWS-owned Account Section */}
              <div className="border-2 border-green-300 bg-green-50 dark:bg-green-950/30 rounded-lg p-4 mt-4 relative">
                <div className="absolute -top-3 left-4 bg-white dark:bg-gray-900 px-2 rounded-md">
                  <div className="flex items-center">
                    <img
                      src="https://d1.awsstatic.com/logos/aws-logo-lockups/poweredbyaws/PB_AWS_logo_RGB_stacked_REV_SQ.91cd4af40773cbfbd15577a3c2b8a346fe3e8fa2.png"
                      alt="AWS Account"
                      width={24}
                      height={24}
                      className="mr-2"
                    />
                    <span className="font-medium text-gray-800 dark:text-gray-200">AWS-owned Account</span>
                  </div>
                </div>

                <div className="flex justify-center gap-8">
                  <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                    <img
                      src="https://cdn.worldvectorlogo.com/logos/aws-bedrock.svg"
                      alt="Bedrock"
                      width={40}
                      height={40}
                    />
                    <span className="text-xs mt-1">Amazon Bedrock</span>
                    <span className="text-[10px] text-gray-500 dark:text-gray-400">Foundation Models</span>
                  </div>
                  <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                    <img
                      src="https://cdn.worldvectorlogo.com/logos/aws-sagemaker.svg"
                      alt="SageMaker"
                      width={40}
                      height={40}
                    />
                    <span className="text-xs mt-1">SageMaker</span>
                    <span className="text-[10px] text-gray-500 dark:text-gray-400">Custom ML Models</span>
                  </div>
                  <div className="p-2 border rounded-lg bg-white dark:bg-gray-700 shadow-md flex flex-col items-center">
                    <img
                      src="https://cdn.worldvectorlogo.com/logos/aws-comprehend.svg"
                      alt="Comprehend"
                      width={40}
                      height={40}
                    />
                    <span className="text-xs mt-1">Comprehend</span>
                    <span className="text-[10px] text-gray-500 dark:text-gray-400">Sentiment Analysis</span>
                  </div>
                </div>
              </div>

              {/* Data Flow Arrows */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                {/* Add SVG arrows here to show data flow */}
                <defs>
                  <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#8C1D40" />
                  </marker>
                  <marker id="arrowhead-blue" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#3B82F6" />
                  </marker>
                  <marker id="arrowhead-green" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#10B981" />
                  </marker>
                  <marker id="arrowhead-purple" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#8B5CF6" />
                  </marker>
                  <marker id="arrowhead-orange" markerWidth="10" markerHeight="7" refX="0" refY="3.5" orient="auto">
                    <polygon points="0 0, 10 3.5, 0 7" fill="#F59E0B" />
                  </marker>
                </defs>

                {/* Client to Frontend (Static Content) */}
                <path
                  d="M100,150 L180,150"
                  stroke="#3B82F6"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-blue)"
                  fill="none"
                />
                <text x="130" y="140" className="text-[8px] fill-blue-600">
                  Static Content
                </text>

                {/* Client to API Gateway (Direct API Calls) */}
                <path
                  d="M100,170 C140,170 400,170 500,170"
                  stroke="#8C1D40"
                  strokeWidth="2"
                  strokeDasharray="5,3"
                  markerEnd="url(#arrowhead)"
                  fill="none"
                />
                <text x="250" y="160" className="text-[8px] fill-red-600">
                  Direct API Calls
                </text>

                {/* Frontend to Auth */}
                <path
                  d="M260,150 L340,150"
                  stroke="#3B82F6"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-blue)"
                  fill="none"
                />

                {/* Auth to API */}
                <path
                  d="M420,150 L500,150"
                  stroke="#3B82F6"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-blue)"
                  fill="none"
                />
                <text x="440" y="140" className="text-[8px] fill-blue-600">
                  Token Validation
                </text>

                {/* API to Lambda */}
                <path d="M540,170 L540,190" stroke="#8C1D40" strokeWidth="2" markerEnd="url(#arrowhead)" fill="none" />

                {/* Lambda to Step Functions */}
                <path
                  d="M540,190 C540,210 500,210 500,190"
                  stroke="#8C1D40"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead)"
                  fill="none"
                />
                <text x="490" y="215" className="text-[8px] fill-red-600">
                  Workflow Orchestration
                </text>

                {/* API to AI Agents */}
                <path
                  d="M580,150 L660,150"
                  stroke="#8B5CF6"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-purple)"
                  fill="none"
                />
                <text x="600" y="140" className="text-[8px] fill-purple-600">
                  Request Routing
                </text>

                {/* AI Agents to Database */}
                <path
                  d="M700,220 L700,320"
                  stroke="#F59E0B"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-orange)"
                  fill="none"
                />
                <text x="710" y="270" className="text-[8px] fill-amber-600">
                  Data Access
                </text>

                {/* Professor Finder to OpenSearch */}
                <path
                  d="M680,220 C680,280 400,280 400,320"
                  stroke="#F59E0B"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-orange)"
                  fill="none"
                />
                <text x="500" y="270" className="text-[8px] fill-amber-600">
                  Search Queries
                </text>

                {/* Activity Tracker to DynamoDB */}
                <path
                  d="M660,220 C660,290 300,290 300,320"
                  stroke="#F59E0B"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-orange)"
                  fill="none"
                />
                <text x="400" y="280" className="text-[8px] fill-amber-600">
                  User Activity Data
                </text>

                {/* Lambda to AWS-owned */}
                <path
                  d="M540,220 L540,450"
                  stroke="#10B981"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-green)"
                  fill="none"
                />
                <text x="550" y="350" className="text-[8px] fill-green-600">
                  ML Inference
                </text>

                {/* AI Agents to Bedrock */}
                <path
                  d="M700,220 C700,350 300,350 300,450"
                  stroke="#10B981"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-green)"
                  fill="none"
                />
                <text x="400" y="340" className="text-[8px] fill-green-600">
                  LLM Requests
                </text>

                {/* AI Agents to SageMaker */}
                <path
                  d="M680,220 C680,370 400,370 400,450"
                  stroke="#10B981"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-green)"
                  fill="none"
                />
                <text x="500" y="360" className="text-[8px] fill-green-600">
                  Custom Model Inference
                </text>

                {/* Wellness Advisor to Comprehend */}
                <path
                  d="M660,220 C660,390 500,390 500,450"
                  stroke="#10B981"
                  strokeWidth="2"
                  markerEnd="url(#arrowhead-green)"
                  fill="none"
                />
                <text x="600" y="380" className="text-[8px] fill-green-600">
                  Sentiment Analysis
                </text>
              </svg>

              {/* Legend */}
              <div className="absolute bottom-2 right-2 bg-white dark:bg-gray-900 p-2 rounded-md border text-xs">
                <div className="font-medium mb-1">Data Flow Legend</div>
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-3 h-0.5 bg-blue-500"></div>
                  <span className="text-blue-600">Authentication Flow</span>
                </div>
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-3 h-0.5 bg-red-600"></div>
                  <span className="text-red-600">API Processing</span>
                </div>
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-3 h-0.5 bg-purple-600"></div>
                  <span className="text-purple-600">Request Routing</span>
                </div>
                <div className="flex items-center gap-1 mb-1">
                  <div className="w-3 h-0.5 bg-amber-600"></div>
                  <span className="text-amber-600">Data Access</span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-3 h-0.5 bg-green-600"></div>
                  <span className="text-green-600">ML/AI Processing</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Architecture Description */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="font-medium text-asu-maroon">Key Workflows</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5" />
                <span>
                  <span className="font-medium">Authentication Flow:</span> Client apps authenticate via Cognito, which
                  provides tokens for API Gateway access
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-red-500 mt-1.5" />
                <span>
                  <span className="font-medium">API Processing:</span> API Gateway routes requests to Lambda functions,
                  with Step Functions orchestrating complex workflows
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-purple-500 mt-1.5" />
                <span>
                  <span className="font-medium">AI Agent Routing:</span> Requests are directed to specialized AI agents
                  based on query type and intent
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-amber-500 mt-1.5" />
                <span>
                  <span className="font-medium">Data Access:</span> AI agents interact with appropriate databases -
                  DynamoDB for user data, OpenSearch for professor information
                </span>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium text-asu-maroon">AI Integration</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-1.5" />
                <span>
                  <span className="font-medium">Bedrock Integration:</span> AI agents leverage Bedrock foundation models
                  for natural language understanding and generation
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-1.5" />
                <span>
                  <span className="font-medium">SageMaker Models:</span> Custom ML models for personalized
                  recommendations and predictions run on SageMaker
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500 mt-1.5" />
                <span>
                  <span className="font-medium">Sentiment Analysis:</span> Wellness Advisor uses Comprehend to analyze
                  student sentiment and stress levels
                </span>
              </li>
              <li className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5" />
                <span>
                  <span className="font-medium">Event Processing:</span> EventBridge triggers automated workflows based
                  on schedule or user activity patterns
                </span>
              </li>
            </ul>
          </div>
        </div>

        {/* Data Flow Description */}
        <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg border shadow-sm">
          <h3 className="font-medium text-asu-maroon mb-2">Complete Request Flow</h3>
          <ol className="space-y-2 text-sm list-decimal pl-5">
            <li>
              <span className="font-medium">User Interaction:</span> Users interact through web/mobile apps, with static
              content served via CloudFront and API calls going directly to API Gateway
            </li>
            <li>
              <span className="font-medium">Authentication:</span> Cognito verifies user identity and provides secure
              tokens that are validated by API Gateway before processing requests
            </li>
            <li>
              <span className="font-medium">API Processing:</span> API Gateway routes requests to appropriate Lambda
              functions, with Step Functions orchestrating complex workflows
            </li>
            <li>
              <span className="font-medium">AI Agent Selection:</span> Based on the request type, the appropriate AI
              agent (Scheduler, Professor Finder, Activity Tracker, or Wellness Advisor) is invoked
            </li>
            <li>
              <span className="font-medium">Data Access & ML Processing:</span> AI agents access data from DynamoDB and
              OpenSearch while leveraging ML models from Bedrock, SageMaker, and Comprehend
            </li>
            <li>
              <span className="font-medium">Response Generation:</span> The system generates a comprehensive response by
              combining outputs from all agents and returns it to the user
            </li>
          </ol>
        </div>
      </CardContent>
    </Card>
  )
}

